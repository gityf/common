#include <pthread.h>
#include <easy/easy_io_struct.h>
#include <easy/easy_log.h>
#include <easy/easy_baseth_pool.h>
#include <easy/easy_connection.h>
#include <easy/easy_message.h>

__thread easy_baseth_t *easy_baseth_self __attribute__ ((tls_model ("initial-exec")));
extern void easy_request_sleeping(easy_request_t *r);
extern void easy_request_wakeup(easy_request_t *r);
static void easy_baseth_pool_invoke(struct ev_loop *loop);
static void easy_baseth_pool_invoke_debug(struct ev_loop *loop);

/**
 * wakeup
 */
void easy_baseth_on_wakeup(void *args)
{
    easy_baseth_t           *th = (easy_baseth_t *)args;

    easy_spin_lock(&th->thread_lock);
    ev_async_send(th->loop, &th->thread_watcher);
    easy_spin_unlock(&th->thread_lock);
}

void easy_baseth_init(void *args, easy_thread_pool_t *tp,
                      easy_baseth_on_start_pt *start, easy_baseth_on_wakeup_pt *wakeup)
{
    easy_baseth_t           *th = (easy_baseth_t *)args;
    th->idx = (((char *)(th)) - (&(tp)->data[0])) / (tp)->member_size;
    th->hcode = th->idx + (tp)->thread_count;
    th->on_start = start;
    th->version_key = EASY_VERSION_KEY;

    th->loop = ev_loop_new(0);
    th->thread_lock = 0;
    th->lastrun = 0.0;

    easy_list_init(&th->task_list);
    easy_list_init(&th->pwait_list);
    ev_async_init (&th->thread_watcher, wakeup);
    th->thread_watcher.data = th;
    ev_async_start (th->loop, &th->thread_watcher);

    ev_set_userdata(th->loop, th);

    if (tp->monitor_tid) {
        ev_set_invoke_pending_cb(th->loop, easy_baseth_pool_invoke_debug);
    } else {
        ev_set_invoke_pending_cb(th->loop, easy_baseth_pool_invoke);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * 创建一个thread pool
 */
easy_thread_pool_t *easy_baseth_pool_create(easy_io_t *eio, int thread_count, int member_size)
{
    easy_baseth_t           *th;
    easy_thread_pool_t      *tp;
    int                     size;

    eio->pool->flags = 1;

    if (thread_count <= 0)
        return NULL;

    member_size = easy_align(member_size, 128);
    size = sizeof(easy_thread_pool_t) + member_size * thread_count;

    if ((tp = (easy_thread_pool_t *) easy_pool_calloc(eio->pool, size)) == NULL)
        return NULL;

    tp->eio = eio;
    tp->thread_count = thread_count;
    tp->member_size = member_size;
    tp->last = &tp->data[0] + member_size * thread_count;
    easy_list_init(&tp->once_start_list);
    easy_list_init(&tp->once_end_list);

    easy_thread_pool_for_each(th, tp, 0) {
        th->eio = eio;
        th->etp = tp;
    }

    easy_spin_lock(&eio->lock);
    easy_list_add_tail(&tp->list_node, &eio->thread_pool_list);
    easy_spin_unlock(&eio->lock);

    // start monitor
    const char *ptr = getenv("easy_thread_monitor");

    if (ptr && (*ptr == 'y' || *ptr == 'Y')) {
        easy_baseth_pool_monitor(tp);
    }

    return tp;
}

void easy_baseth_pool_start(easy_thread_pool_t *tp)
{
    easy_baseth_t   *th;
    easy_io_t       *eio;

    eio = tp->eio;
    easy_spin_lock(&eio->lock);

    if (eio->started) {
        easy_thread_pool_for_each(th, tp, 0) {
            if (pthread_create(&(th->tid), NULL, th->on_start, (void *)th)) {
                abort();
            }
        }
    }

    easy_spin_unlock(&eio->lock);
}

/**
 * stop pool
 */
void easy_baseth_pool_stop(easy_thread_pool_t *tp)
{
    easy_baseth_t           *th;
    tp->stoped = 1;
    easy_thread_pool_for_each(th, tp, 0) {
        th->stoped = 1;
        easy_baseth_on_wakeup(th);
    }
}

void easy_baseth_pool_wait(easy_thread_pool_t *tp)
{
    easy_baseth_t           *th;
    easy_thread_pool_for_each(th, tp, 0) {
        if (th->tid && pthread_join(th->tid, NULL) == EDEADLK) {
            easy_fatal_log("easy_io_wait fatal, eio=%p, tid=%lx\n", th->eio, th->tid);
            abort();
        }

        th->tid = 0;
    }

    if (tp->monitor_tid && pthread_join(tp->monitor_tid, NULL) == EDEADLK) {
        easy_fatal_log("easy_io_wait fatal, eio=%p, tid=%lx\n", tp->eio, tp->monitor_tid);
        abort();
    }
}

/**
 * destroy pool
 */
void easy_baseth_pool_destroy(easy_thread_pool_t *tp)
{
    easy_baseth_t           *th;
    easy_list_del(&tp->list_node);
    easy_thread_pool_for_each(th, tp, 0) {
        ev_loop_destroy(th->loop);
    }
}

static void easy_baseth_pool_wakeup_session(easy_baseth_t *th)
{
    if (th->iot == 0)
        return;

    easy_connection_t       *c, *c1;
    easy_session_t          *s;
    easy_io_thread_t        *ioth = (easy_io_thread_t *) th;

    // session at ioth
    easy_list_for_each_entry_safe(c, c1, &ioth->task_list, conn_list_node) {
        if (c->task_type == EASY_TASK_TYPE_SESSION) {
            s = (easy_session_t *) c;

            if (s->status == 0) {
                easy_list_del(&s->session_list_node);
                easy_session_process(s, 0);
            }
        } else if (c->task_type == EASY_TASK_TYPE_CONN) {
            easy_connection_wakeup_session(c);
        }
    }
    // foreach connected_list
    easy_list_for_each_entry_safe(c, c1, &ioth->connected_list, conn_list_node) {
        easy_connection_wakeup_session(c);
    }
}

// uthread的处理函数
void easy_baseth_pool_invoke(struct ev_loop *loop)
{
    easy_baseth_t           *th = (easy_baseth_t *) ev_userdata (loop);

    // 是否退出
    if (th->stoped) {
        easy_baseth_pool_wakeup_session(th);
        ev_break(loop, EVBREAK_ALL);
        return;
    }

    th->lastrun = ev_now(loop);
    ev_invoke_pending(loop);

    if (easy_list_empty(&th->task_list) == 0) {
        (ev_cb(&th->thread_watcher))(loop, &th->thread_watcher, 0);
    }

    easy_uthread_loop_yield(th->euc);

    if (th->thread_watcher.sent == 2) {
        th->thread_watcher.sent = 0;
        ev_async_self(th->loop, &th->thread_watcher);
    }

    th->lastrun = 0.0;
}

void easy_baseth_pool_invoke_debug(struct ev_loop *loop)
{
    ev_tstamp st = ev_time();
    easy_baseth_pool_invoke(loop);
    ev_tstamp et = ev_time();

    if (et - st > 1.0) {
        easy_error_log("SLOW: start: %f end: %f cost: %f", st, et, et - st);
    }
}

/**
 * register 线程开始调用的函数
 */

void easy_baseth_register_once(easy_thread_pool_t *tp,
                               easy_thread_once_pt *once, void *args, int end)
{
    easy_io_t           *eio;
    easy_thread_once_t  *to;

    eio = tp->eio;
    to = (easy_thread_once_t *) easy_pool_alloc(eio->pool, sizeof(easy_thread_once_t));
    to->once = once;
    to->args = args;

    easy_spin_lock(&eio->lock);

    if (end) {
        easy_list_add_tail(&to->node, &tp->once_end_list);
    } else {
        easy_list_add_tail(&to->node, &tp->once_start_list);
    }

    easy_spin_unlock(&eio->lock);
}

/**
 * 执行once
 */
void easy_baseth_call_once(easy_baseth_t *th, easy_list_t *list)
{
    easy_thread_once_t  *to;

    easy_list_for_each_entry(to, list, node) {
        (to->once)(th, to->args);
    }
}

void easy_baseth_async_lite(easy_baseth_t *ioth, easy_task_t *r)
{
    easy_spin_lock(&ioth->thread_lock);
    easy_list_add_tail(&r->task_list_node, &ioth->task_list);
    easy_spin_unlock(&ioth->thread_lock);

    if (ioth == easy_baseth_self) {
        ioth->thread_watcher.sent = 2;
    } else {
        ev_async_send(ioth->loop, &ioth->thread_watcher);
    }
}

/**
 * WORK线程的回调程序
 */
void easy_baseth_on_process(struct ev_loop *loop, ev_async *w, int revents)
{
    easy_baseth_t               *th;
    easy_task_t                 *r, *r2;
    easy_list_t                 request_list;

    th = (easy_baseth_t *) w->data;

    easy_spin_lock(&th->thread_lock);
    easy_list_movelist(&th->task_list, &request_list);
    easy_spin_unlock(&th->thread_lock);

    easy_list_for_each_entry_safe(r, r2, &request_list, task_list_node) {
        easy_list_del(&r->task_list_node);

        if (r->task_process) {
            (r->task_process)(th, r);
        } else {
            easy_baseth_task_process(th, r);
        }
    }
    easy_connection_pwait_flush(th);
}

// push request
int easy_baseth_task_process(easy_baseth_t *th, easy_task_t *r)
{
    int retcode = (th->process)(th, r);

    if (retcode != EASY_ABORT && r->istask == 0) {
        r->retcode = retcode;
        easy_request_wakeup((easy_request_t *)r);
    }

    return EASY_OK;
}

void easy_baseth_set_process(easy_thread_pool_t *tp, easy_task_process_pt *cb, void *args)
{
    easy_baseth_t   *th;
    easy_thread_pool_for_each(th, tp, 0) {
        th->process = cb;
        th->args = args;
    }
}

// push request
int easy_thread_pool_push(easy_thread_pool_t *tp, easy_request_t *r, uint64_t hv)
{
    easy_request_sleeping(r);
    easy_list_del(&r->request_list_node);
    return easy_thread_pool_addin(tp, (easy_task_t *)r, hv);
}

// push task
int easy_thread_pool_addin(easy_thread_pool_t *tp, easy_task_t *r, uint64_t hv)
{
    easy_baseth_t *th = (easy_baseth_t *)easy_thread_pool_hash(tp, hv);
    easy_baseth_async_lite(th, r);
    return EASY_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
static void *easy_baseth_pool_monitor_func(void *args)
{
    easy_baseth_t           *th;
    easy_thread_pool_t      *tp = (easy_thread_pool_t *) args;

    while(tp->stoped == 0) {
        usleep(1000000);
        ev_tstamp now = ev_time();
        easy_thread_pool_for_each(th, tp, 0) {
            ev_tstamp last = th->lastrun;

            if (last > 0 && now - last > 1.0) {
                pthread_kill(th->tid, 40);
                easy_error_log("SLOW: thread: %lx, lastrun: %f cost: %f", th->tid, last, now - last);
            }
        }
    }

    return NULL;
}


static void easy_baseth_pool_sighand(int sig)
{
    EASY_PRINT_BT("sig: %d\n", sig);
}

void easy_baseth_pool_monitor(easy_thread_pool_t *tp)
{
    if (tp->monitor_tid) {
        return;
    }

    int                     rc;
    struct sigaction        actions;
    memset(&actions, 0, sizeof(actions));
    sigemptyset(&actions.sa_mask);
    actions.sa_flags = SA_RESTART;
    actions.sa_handler = easy_baseth_pool_sighand;
    rc = sigaction(40, &actions, NULL);
    pthread_create(&tp->monitor_tid, NULL, easy_baseth_pool_monitor_func, tp);
    easy_error_log("sigaction: %d, monitor_thread: 0x%lx", rc, tp->monitor_tid);
}


#include <fcntl.h>
#include <sys/epoll.h>
#include <easy/easy_io.h>
#include <easy/easy_client.h>
#include <easy/easy_connection.h>
#include <easy/easy_message.h>

/**
 * 把session发送到addr上
 */
int easy_client_dispatch(easy_io_t *eio, easy_addr_t addr, easy_session_t *s)
{
    easy_io_thread_t        *ioth;
    uint64_t                index;
    int                     issend;

    if (unlikely(eio->stoped)) {
        easy_error_log("easy_io_dispatch is failure: stoped: %d\n", eio->stoped);
        return EASY_ERROR;
    }

    if ((index = (addr.cidx & 0xff)) == 0) {
        index = easy_fnv_hashcode(&addr, sizeof(easy_addr_t), 7);
    }

    ioth = (easy_io_thread_t *)easy_thread_pool_hash(eio->io_thread_pool, index);
    issend = (s->status == 0 || s->status == EASY_CONNECT_SEND);
    s->queuesize = ioth->doing_request_count;

    if (unlikely(ioth->eio->checkdrc == 0 && ioth->doing_request_count >= eio->queue_size && issend)) {
        static int              lastlog = 0;

        if (lastlog != time(NULL)) {
            lastlog = time(NULL);
            easy_error_log("ioth->doing_request_count: %d, queue_size: %d\n",
                           ioth->doing_request_count, eio->queue_size);
        }

        return EASY_ERROR;
    }

    s->async = 1;
    s->addr = addr;

    if (issend) easy_atomic32_inc(&ioth->doing_request_count);

#ifndef NDEBUG
    char buffer[64];
    easy_debug_log("send to %s, status=%d", easy_inet_addr_to_str(&s->addr, buffer, 64), s->status);
#endif

    // dispatch
    assert(s->task_type == EASY_TASK_TYPE_SESSION);
    easy_baseth_async_p(ioth, s, easy_connection_tasksession);

    return EASY_OK;
}
/**
 * thread发送packet的时候用, 同步, 等待返回结果
 */
void *easy_client_send(easy_io_t *eio, easy_addr_t addr, easy_session_t *s)
{
    int                     ret;
    easy_client_wait_t      wobj;

    easy_client_wait_init(&wobj);
    easy_session_set_wobj(s, &wobj);
    s->process = easy_client_wait_process;

    if ((ret = easy_client_dispatch(eio, addr, s)) == EASY_ERROR) {
        s->error = 1;
        easy_warn_log("easy_session_dispatch: %d\n", ret);
        return NULL;
    }

    easy_error_log("wait for data");
    easy_client_wait(&wobj, 1);
    easy_error_log("data recv");
    pthread_cond_destroy(&wobj.cond);
    pthread_mutex_destroy(&wobj.mutex);
    return s->r.ipacket;
}

// init
void easy_client_wait_init(easy_client_wait_t *w)
{
    w->done_count = 0;
    w->status = EASY_CONN_OK;
    easy_list_init(&w->next_list);
    easy_list_init(&w->session_list);
    pthread_mutex_init(&w->mutex, NULL);
    pthread_cond_init(&w->cond, NULL);
}

void easy_client_wait_cleanup(easy_client_wait_t *w)
{
    easy_session_t          *s, *s2;
    pthread_cond_destroy(&w->cond);
    pthread_mutex_destroy(&w->mutex);
    easy_list_for_each_entry_safe(s, s2, &w->session_list, session_list_node) {
        easy_session_destroy(s);
    }
}
void easy_client_wait_wakeup(easy_client_wait_t *w)
{
    pthread_mutex_lock(&w->mutex);
    w->done_count ++;
    pthread_cond_signal(&w->cond);
    pthread_mutex_unlock(&w->mutex);
}
void easy_client_wait_wakeup_request(easy_request_t *r)
{
    if (r->client_wait) {
        easy_atomic_inc(&r->ms->c->pool->ref);
        easy_atomic_inc(&r->ms->pool->ref);
        easy_client_wait_wakeup(r->client_wait);
    }
}
void easy_client_wait(easy_client_wait_t *w, int count)
{
    pthread_mutex_lock(&w->mutex);

    while(w->done_count < count) {
        pthread_cond_wait(&w->cond, &w->mutex);
    }

    pthread_mutex_unlock(&w->mutex);

    if (easy_list_empty(&w->next_list))
        return;

    // next
    easy_list_t             *list = &w->next_list;
    easy_session_t          *s, *sn;
    int                     cnt = 0;

    easy_list_for_each_entry_safe(s, sn, list, session_list_node) {
        w = (easy_client_wait_t *)s->r.request_list_node.prev;

        easy_list_del(&s->session_list_node);
        easy_list_add_tail(&s->session_list_node, &w->session_list);

        if (++ cnt >= 2) {
            easy_list_movelist(list, &w->next_list);
            easy_client_wait_wakeup(w);
            break;
        } else {
            easy_client_wait_wakeup(w);
        }
    }
}

int easy_client_wait_process(easy_request_t *r)
{
    easy_client_wait_t      *w = (easy_client_wait_t *)r->request_list_node.prev;
    easy_session_t          *s = (easy_session_t *)r->ms;

    pthread_mutex_lock(&w->mutex);
    easy_list_add_tail(&s->session_list_node, &w->session_list);
    w->done_count ++;
    pthread_cond_signal(&w->cond);
    pthread_mutex_unlock(&w->mutex);

    return EASY_OK;
}

int easy_client_wait_batch_process(easy_message_t *m)
{
    easy_list_t             *list = (easy_list_t *) m;
    easy_session_t          *s;
    easy_client_wait_t      *w;

    s = easy_list_get_first(list, easy_session_t, session_list_node);
    w = (easy_client_wait_t *)s->r.request_list_node.prev;

    easy_list_del(&s->session_list_node);
    easy_list_add_tail(&s->session_list_node, &w->session_list);

    easy_list_movelist(list, &w->next_list);
    easy_client_wait_wakeup(w);
    return EASY_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// add addr
int easy_client_list_add(easy_hash_t *table, easy_addr_t *addr, easy_hash_link_t *list)
{
    uint64_t                n;
    easy_hash_link_t        *first;

    n = easy_fnv_hashcode(addr, sizeof(easy_addr_t), 5);
    n &= table->mask;

    // init
    table->count ++;
    table->seqno ++;

    // add to list
    first = table->buckets[n];
    list->next = first;

    if (first) first->pprev = &list->next;

    table->buckets[n] = list;
    list->pprev = &(table->buckets[n]);

    return EASY_OK;
}

easy_client_t *easy_client_list_find(easy_hash_t *table, easy_addr_t *addr)
{
    uint64_t                n;
    easy_hash_link_t        *list;
    easy_client_t           *client;

    n = easy_fnv_hashcode(addr, sizeof(easy_addr_t), 5);
    n &= table->mask;
    list = table->buckets[n];

    // foreach
    while(list) {
        client = (easy_client_t *) ((char *)list - table->offset);
        uint64_t *a = (uint64_t *)&client->addr;
        uint64_t *b = (uint64_t *)addr;

        if (a[2] == b[2] && a[0] == b[0] && a[1] == b[1]) {
            return client;
        }

        list = list->next;
    }

    return NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int easy_cond_init(easy_cond_t *cond)
{
    int                evfd;
    struct epoll_event ev;

    cond->fd[0] = -1;
    cond->fd[1] = -1;
    cond->epfd = -1;
    cond->len = 1;
    cond->pending = 0;

    evfd = ez_eventfd (0, O_NONBLOCK | FD_CLOEXEC);

    if (evfd < 0 && errno == EINVAL)
        evfd = ez_eventfd (0, 0);

    if (evfd >= 0) {
        cond->fd[0] = evfd;
        cond->fd[1] = evfd;
        fcntl (evfd, F_SETFD, FD_CLOEXEC);
        fcntl (evfd, F_SETFL, O_NONBLOCK);
        cond->len = sizeof(uint64_t);
    } else {
        if (pipe(cond->fd)) {
            easy_error_log("[%p] pipe is error: %s (%d)", cond, strerror(errno), errno);
            return EASY_ERROR;
        }

        fcntl (cond->fd[0], F_SETFD, FD_CLOEXEC);
        fcntl (cond->fd[1], F_SETFD, FD_CLOEXEC);
        fcntl (cond->fd[0], F_SETFL, O_NONBLOCK | O_NOATIME);
        fcntl (cond->fd[1], F_SETFL, O_NONBLOCK);
    }

    if ((evfd = epoll_create(1)) == -1) {
        easy_error_log("[%p] epoll_create: %s (%d)", cond, strerror(errno), errno);
        return EASY_ERROR;
    }

    cond->epfd = evfd;
    ev.events = EPOLLIN;
    ev.data.u64 = 0;
    ev.data.fd = cond->fd[0];

    if (epoll_ctl(cond->epfd, EPOLL_CTL_ADD, cond->fd[0], &ev) == -1) {
        easy_error_log("[%p] epoll_ctl: %s (%d)", cond, strerror(errno), errno);
        return EASY_ERROR;
    }

    return EASY_OK;
}

int easy_cond_destroy(easy_cond_t *cond)
{
    if (cond->fd[1] != cond->fd[0]) easy_safe_close(cond->fd[1]);

    easy_safe_close(cond->fd[0]);
    easy_safe_close(cond->epfd);
    return EASY_ERROR;
}

int easy_cond_wait(easy_cond_t *cond, int timeout)
{
    uint64_t                id;
    struct epoll_event      ev;
    int                     ret;

    do {
        ret = epoll_wait(cond->epfd, &ev, 1, timeout);
    } while(ret < 0 && errno == EINTR);

    if (ret < 0) {
        easy_error_log("[%p] epoll_wait: %d, %s (%d)", cond, cond->epfd, strerror(errno), errno);
        return EASY_ERROR;
    } else if (ret == 0) {
        return EASY_ABORT;
    }

    ret = read(ev.data.fd, &id, cond->len);
    cond->pending = 0;

    return EASY_OK;
}

int easy_cond_signal(easy_cond_t *cond)
{
    if (cond->pending == 0) {
        uint64_t                id = 1;
        cond->pending = 1;
        easy_ignore(write(cond->fd[1], &id, cond->len));
    }

    return EASY_OK;
}


#!/bin/bash

cat <<EOF > aversion.c
#include <easy/easy_io.h>
#ifdef BUILD_MAIN
#include "aversion.h"
uint64_t hashcode(const void *key, int len, unsigned int seed)
{const uint64_t m = __UINT64_C(0xc6a4a7935bd1e995);const int r = 47;uint64_t h = seed ^ (len * m);
const uint64_t *data = (const uint64_t *)key;const uint64_t *end = data + (len / 8);
while(data != end) {uint64_t k = *data++;k *= m; k ^= k >> r; k *= m; h ^= k; h *= m;}
h ^= h >> r; h *= m; h ^= h >> r; return h;} int main() { int i = 0; char buffer[1024];
memset(buffer, 0, sizeof(buffer)); char *p = buffer; for(i = 0; i < sizeof(st) / sizeof(st[0]); i++) {
p += snprintf(p, 32, "%d,", st[i]); } fprintf(stdout, "%lu", hashcode(buffer, strlen(buffer)+7, 7));return 0;}
#endif
EOF

gcc -I ../../include -E -o aversion.txt -E aversion.c
fgrep 'typedef struct easy' aversion.txt | awk '{print $3}' | sort -u | awk 'BEGIN{print "int st[] ={"}{print "sizeof("$0"),"}END{print"0};"}' > aversion.h
gcc -Wall -Werror -I ../../include -DBUILD_MAIN=1 -o aversion aversion.c
version_key=`./aversion`
rm -f aversion.txt aversion.c aversion.h aversion
if [ -z "`fgrep ${version_key} ../include/easy_define.h`" ]; then
sed -i -e "/#define EASY_VERSION_KEY/ s/#define EASY_VERSION_KEY.*/#define EASY_VERSION_KEY            ${version_key}LLU/g" ../include/easy_define.h
fi

BUILDTIME=`/bin/date +'%F %T'`;
SVNINFO=`LANG=en_US /usr/bin/svn info ../../.. | egrep '(URL:)'`;
REVINFO=`LANG=en_US /usr/bin/svn log --non-interactive -l1 ../../.. --xml | fgrep "revision=" | awk -F\" '{print $2}'`
echo "char *easy_build_time = \"LIBEASY VERSION:$MVERSION KEY:$version_key BUILDTIME:$BUILDTIME $SVNINFO \"" > easy_version.c
echo "\"Revision:$REVINFO BUILDHOST:`id -un`@`hostname``readlink -f ../../..`\";" >> easy_version.c
echo "unsigned long long easy_version_key = ${version_key}LLU;" >> easy_version.c

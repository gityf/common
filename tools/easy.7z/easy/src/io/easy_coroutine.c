#include <easy/easy_io.h>

#define EASY_CORO_USLEEP 100
static void *easy_coroutine_on_start(void *args);
static int easy_coroutine_uthread_ready(easy_baseth_t *th, easy_task_t *rt);

// coroutine thread pool
easy_thread_pool_t *easy_coroutine_pool_create(easy_io_t *eio, int cnt, easy_task_process_pt *cb, void *args)
{
    easy_thread_pool_t        *tp;
    easy_coroutine_thread_t   *th;

    if ((tp = easy_baseth_pool_create(eio, cnt, sizeof(easy_coroutine_thread_t))) == NULL)
        return NULL;

    // 初始化线程池
    easy_thread_pool_for_each(th, tp, 0) {
        easy_baseth_init(th, tp, easy_coroutine_on_start, easy_baseth_on_process);
        th->process = cb;
        th->args = args;
    }

    // join
    easy_spin_lock(&eio->lock);
    tp->next = eio->thread_pool;
    eio->thread_pool = tp;
    easy_spin_unlock(&eio->lock);

    return tp;
}

static void *easy_coroutine_on_start(void *args)
{
    easy_io_t               *eio;
    easy_coroutine_thread_t *th;

    // init
    th = (easy_coroutine_thread_t *) args;
    th->started = 1;
    eio = th->eio;
    easy_baseth_self = (easy_baseth_t *) th;
    easy_debug_log("[%p] pthread start: %p\n", eio, th);

    if (eio->block_thread_signal)
        pthread_sigmask(SIG_BLOCK, &eio->block_thread_sigset, NULL);

    easy_thread_pool_runloop(th);

    // exit
    easy_baseth_self = NULL;
    easy_debug_log("[%p] pthread exit: %lx.\n", eio, pthread_self());

    return (void *) NULL;
}

static void easy_coroutine_on_later(struct ev_loop *loop, ev_timer *w, int revents)
{
    easy_task_t *r = (easy_task_t *) w->data;
    (r->task_process)(easy_baseth_self, r);
}

static int easy_coroutine_uthread_ready(easy_baseth_t *th, easy_task_t *r)
{
    easy_uthread_ready((easy_uthread_t *)r);
    return EASY_OK;
}

static int easy_coroutine_newandrun(easy_baseth_t *th, easy_task_t *r)
{
    easy_uthread_exec(th->euc, (easy_uthread_start_pt *)r->timeout_watcher.data, th, r);
    return EASY_OK;
}

void easy_coroutine_process_set(easy_task_t *r, easy_task_process_pt *process)
{
    r->task_process = easy_coroutine_newandrun;
    r->timeout_watcher.data = process ? (void *)process : easy_baseth_task_process;
}

int easy_coroutine_process(easy_baseth_t *th, easy_task_t *r)
{
    if (r->istimer) {
        r->istimer = 0;
        ev_init(&r->timeout_watcher, easy_coroutine_on_later);
        r->timeout_watcher.data = r;
        ev_timer_start(th->loop, &r->timeout_watcher);
    } else if (r->iscoro == 1) {
        r->iscoro = 2;
        easy_uthread_exec(th->euc, (easy_uthread_start_pt *)easy_coroutine_process, th, r);
    } else {
        r->task_process = NULL;
        easy_baseth_task_process(th, r);
    }

    return EASY_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
static void easy_coroutine_on_usleep(struct ev_loop *loop, ev_timer *w, int revents)
{
    easy_uthread_t *runut = (easy_uthread_t *) w->data;
    easy_uthread_ready(runut);
}

static void easy_coroutine_on_timeout(struct ev_loop *loop, ev_timer *w, int revents)
{
    easy_uthread_t *runut = (easy_uthread_t *) w->data;
    easy_comutex_t *l = (easy_comutex_t *)runut->task_args;
    easy_spin_lock(&l->wlock);
    easy_list_del(&runut->task_list_node);
    easy_spin_unlock(&l->wlock);
    easy_uthread_ready(runut);
}

void easy_coroutine_wakeup_uthread(easy_uthread_t *t)
{
    easy_coroutine_thread_t     *th;
    th = (easy_coroutine_thread_t *)t->threadptr;

    if (th == (easy_coroutine_thread_t *)easy_baseth_self) {
        easy_uthread_ready(t);
    } else { // other thread
        easy_baseth_async_p(th, t, easy_coroutine_uthread_ready);
    }
}

int easy_coroutine_usleep(int64_t us)
{
    if (us <= 0) return EASY_OK;

    ev_timer                timeout_watcher;
    easy_uthread_t          *runut;
    easy_coroutine_thread_t *th;

    if ((runut = easy_uthread_current()) == NULL) {
        usleep(us);
        return EASY_OK;
    }

    us = easy_max(us, 1);
    th = (easy_coroutine_thread_t *) easy_baseth_self;
    ev_timer_init(&timeout_watcher, easy_coroutine_on_usleep, us / 1000000.0, 0.0);
    timeout_watcher.data = runut;
    ev_timer_start(th->loop, &timeout_watcher);
    easy_uthread_switch();

    return EASY_OK;
}

#define EASY_LOCK_DEBUG(format, args...) //easy_error_log(format, ##args)
int easy_comutex_init(easy_comutex_t *l)
{
    l->lock = 0;
    l->wlock = 0;
    l->owner = 0;
    easy_list_init(&l->wlist);
    return EASY_OK;
}

int easy_comutex_lock(easy_comutex_t *l)
{
    easy_uthread_t *runut = easy_uthread_current();

    int skip = 0;

    if (runut == NULL) {
        while(1) {
            easy_spin_lock(&l->wlock);

            if (l->lock == 0 || l->owner == pthread_self()) {
                skip = 1;
                l->lock ++;
                l->owner = pthread_self();
                EASY_LOCK_DEBUG("LOCK:%p, value:%ld", l, l->lock);
            }

            easy_spin_unlock(&l->wlock);

            if (skip) break;

            EASY_LOCK_DEBUG("WAITLOCK:%p, value:%ld", l, l->lock);
            usleep(EASY_CORO_USLEEP);
        }

        return EASY_OK;
    }

    while(1) {
        easy_spin_lock(&l->wlock);

        if (l->lock == 0 || l->owner == (long)runut) {
            skip = 1;
            l->lock ++;
            l->owner = (long)runut;
            EASY_LOCK_DEBUG("LOCK:%p, value:%ld, ut:%u_%u", l, l->lock, runut->tid, runut->coid);
        } else {
            easy_list_add_tail(&runut->task_list_node, &l->wlist);
        }

        easy_spin_unlock(&l->wlock);

        if (skip) break;

        EASY_LOCK_DEBUG("WAITLOCK:%p, value:%ld, ut:%u_%u", l, l->lock, runut->tid, runut->coid);
        easy_uthread_switch();
    }

    return EASY_OK;
}

int easy_comutex_unlock(easy_comutex_t *l)
{
    // wait_list
    easy_uthread_t              *t = NULL;

    // unlock
    assert(l->lock);

    easy_spin_lock(&l->wlock);
    EASY_LOCK_DEBUG("UNLOCK:%p, value:%ld, owner:%ld", l, l->lock - 1, l->owner);

    if (-- l->lock == 0) {
        l->owner = 0;
    }

    easy_spin_unlock(&l->wlock);

    // wakeup
    if (easy_list_empty(&l->wlist) == 0) {
        easy_spin_lock(&l->wlock);

        if (easy_list_empty(&l->wlist) == 0) {
            t = easy_list_entry(l->wlist.next, easy_uthread_t, task_list_node);
            easy_list_del(&t->task_list_node);
        }

        easy_spin_unlock(&l->wlock);
    }

    if (t) {
        easy_coroutine_wakeup_uthread(t);
    }

    return EASY_OK;
}

void easy_comutex_cond_lock(easy_comutex_t *l)
{
    easy_spin_lock(&l->lock);
}

void easy_comutex_cond_unlock(easy_comutex_t *l)
{
    easy_spin_unlock(&l->lock);
}

int easy_comutex_cond_wait(easy_comutex_t *l)
{
    easy_uthread_t *runut = easy_uthread_current();

    long old = l->owner;

    if (runut == NULL) {
        while(1) {
            if (l->owner != old) {
                break;
            }

            easy_spin_unlock(&l->lock);
            usleep(EASY_CORO_USLEEP);
            easy_spin_lock(&l->lock);
        }

        return EASY_OK;
    }

    while(1) {
        if (l->owner != old) {
            break;
        }

        easy_spin_unlock(&l->lock);

        // add to wait
        easy_spin_lock(&l->wlock);
        easy_list_add_tail(&runut->task_list_node, &l->wlist);
        easy_spin_unlock(&l->wlock);

        EASY_LOCK_DEBUG("COND_WAIT: %p, ut: %u_%u, owner: %ld, old: %ld", l, runut->tid, runut->coid, l->owner, old);
        easy_uthread_switch();

        easy_spin_lock(&l->lock);
    }

    EASY_LOCK_DEBUG("COND_WAIT_END: %p, ut: %u_%u, owner: %ld, old: %ld", l, runut->tid, runut->coid, l->owner, old);
    return EASY_OK;
}

int easy_comutex_cond_signal(easy_comutex_t *l)
{
    l->owner ++;
    easy_spin_unlock(&l->lock);

    easy_uthread_t *t = NULL;
    easy_spin_lock(&l->wlock);

    if (easy_list_empty(&l->wlist) == 0) {
        t = easy_list_entry(l->wlist.next, easy_uthread_t, task_list_node);
        easy_list_del(&t->task_list_node);
        EASY_LOCK_DEBUG("COND_SIGNAL: %p, ut: %u_%u, owner: %ld", l, t->tid, t->coid, l->owner);
        easy_coroutine_wakeup_uthread(t);
    }

    easy_spin_unlock(&l->wlock);
    easy_spin_lock(&l->lock);

    return EASY_OK;
}

int easy_comutex_cond_broadcast(easy_comutex_t *l)
{
    l->owner ++;
    easy_spin_unlock(&l->lock);

    easy_uthread_t *t, *t1;

    easy_spin_lock(&l->wlock);
    easy_list_for_each_entry_safe(t, t1, &l->wlist, task_list_node) {
        easy_list_del(&t->task_list_node);
        easy_coroutine_wakeup_uthread(t);
    }

    easy_list_init(&l->wlist);
    easy_spin_unlock(&l->wlock);
    easy_spin_lock(&l->lock);
    return EASY_OK;
}

int easy_comutex_cond_timedwait(easy_comutex_t *l, int64_t us)
{
    if (us < 0) {
        return easy_comutex_cond_wait(l);
    }

    easy_uthread_t *runut = easy_uthread_current();
    ev_timer        timeout_watcher;
    long            old = l->owner;
    int             ret = EASY_OK;

    if (runut == NULL) {
        while(us > 0) {
            if (l->owner != old) {
                break;
            }

            easy_spin_unlock(&l->lock);
            usleep(EASY_CORO_USLEEP);
            us -= EASY_CORO_USLEEP;
            easy_spin_lock(&l->lock);
        }

        return EASY_OK;
    }

    // wait
    while(us > 0) {
        if (l->owner != old) {
            break;
        }

        easy_spin_unlock(&l->lock);

        // add to wait
        easy_spin_lock(&l->wlock);
        easy_list_add_tail(&runut->task_list_node, &l->wlist);
        easy_spin_unlock(&l->wlock);

        us = easy_max(us, 1000);
        ev_timer_init(&timeout_watcher, easy_coroutine_on_timeout, us / 1000000.0, 0.0);
        timeout_watcher.data = runut;
        runut->task_args = l;
        ev_timer_start(easy_baseth_self->loop, &timeout_watcher);

        EASY_LOCK_DEBUG("COND_WAIT: %p, ut: %u_%u, owner: %ld, old: %ld", l, runut->tid, runut->coid, l->owner, old);
        easy_uthread_switch();

        if (ev_is_active(&timeout_watcher) == 0) {
            ret = EASY_AGAIN;
            us = 0;
        }

        ev_timer_stop(easy_baseth_self->loop, &timeout_watcher);

        easy_spin_lock(&l->lock);
    }

    EASY_LOCK_DEBUG("COND_WAIT_END: %p, ut: %u_%u, owner: %ld, old: %ld", l, runut->tid, runut->coid, l->owner, old);
    return ret;
}


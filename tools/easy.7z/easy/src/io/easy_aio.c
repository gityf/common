/**
 * 对文件异步读写操作
 */
#include <easy/easy_io.h>
#include <easy/easy_aio.h>
#include <easy/easy_baseth_pool.h>
#include <easy/easy_socket.h>
#include <sys/syscall.h>

#define easy_aio_setup(nr, ctx) syscall(__NR_io_setup, nr, ctx)
#define easy_aio_destroy(ctx)   syscall(__NR_io_destroy, ctx)
#define easy_aio_getevents(ctx, min_nr, nr, events, tmo) syscall(__NR_io_getevents, ctx, min_nr, nr, events, tmo)
#define easy_aio_submit(ctx, n, iocb) syscall(__NR_io_submit, ctx, n, iocb)
#define EASY_AIO_MAX_PENDING    128
#define EASY_AIO_MAX_EVENTS     64
#define EASY_AIO_MAX_BATCH      32

static void easy_aio_event_callback(struct ev_loop *loop, ev_io *w, int revents);
static int easy_aio_submit_waitlist(easy_aio_t *aio);

///////////////////////////////////////////////////////////////////////////////////////////////////
static int easy_aio_once_start(easy_baseth_t *th, void *args)
{
    easy_array_t *arr = NULL;
    easy_aio_t   *aio = NULL;
    int           efd = -1;

    if (th->aio) return EASY_OK;

    if ((efd = ez_eventfd (0, 0)) < 0) {
        easy_error_log("eventfd error: %d", errno);
        goto error_exit;
    }

    easy_socket_non_blocking(efd);
    easy_socket_colexec(efd);

    // new array
    if ((arr = easy_array_create(sizeof(easy_aio_task_t))) == NULL)
        goto error_exit;

    if ((aio = easy_pool_calloc(arr->pool, sizeof(easy_aio_t))) == NULL)
        goto error_exit;

    if (easy_aio_setup(EASY_AIO_MAX_PENDING, &aio->ctx) < 0) {
        easy_error_log("easy_io_setup error: %d", errno);
        goto error_exit;
    }

    aio->pool = arr->pool;
    aio->maxsize = (long)args;
    easy_list_init(&aio->list);
    aio->efd = efd;
    aio->arr = arr;
    th->aio = aio;

    // start watcher
    ev_io_init(&aio->watcher, easy_aio_event_callback, efd, EV_READ);
    aio->watcher.data = aio;
    ev_io_start(easy_baseth_self->loop, &aio->watcher);

    return EASY_OK;
error_exit:
    easy_safe_close(efd);

    if (arr) easy_array_destroy(arr);

    return EASY_ERROR;
}

static int easy_aio_once_end(easy_baseth_t *th, void *args)
{
    if (th->aio) {
        easy_aio_destroy(th->aio->ctx);
        easy_safe_close(th->aio->efd);
        easy_array_destroy(th->aio->arr);
        th->aio = NULL;
    }

    return EASY_OK;
}

static void easy_aio_event_callback(struct ev_loop *loop, ev_io *w, int revents)
{
    easy_aio_task_t    *tsk;
    easy_aio_t         *aio;
    easy_aio_event_t    event[EASY_AIO_MAX_EVENTS];
    struct timespec     ts = {0, 0};
    int                 i, events;
    uint64_t            ready;

    aio = (easy_aio_t *)w->data;

    // read aio events cnt
    if (read(aio->efd, &ready, sizeof(uint64_t)) != sizeof(uint64_t)) {
        easy_error_log("read failure from eventfd: %d", errno);
        return;
    }

    // process
    while (ready) {
        events = easy_aio_getevents(aio->ctx, 1, easy_min(ready, EASY_AIO_MAX_EVENTS), event, &ts);

        if (events <= 0) {
            easy_error_log("easy_io_getevents: %d, errno: %d", events, errno);
            return;
        }

        ready -= events;
        aio->pending -= events;
        aio->cursize -= events;

        for (i = 0; i < events; i++) {
            tsk = (easy_aio_task_t *)event[i].data;
            (tsk->cb)(&event[i], tsk->args);
            easy_array_free(aio->arr, tsk);
        }
    }

    while (easy_list_empty(&aio->list) == 0 && aio->pending < EASY_AIO_MAX_PENDING) {
        if (easy_aio_submit_waitlist(aio)) break;
    }
}

static int easy_aio_submit_waitlist(easy_aio_t *aio)
{
    // io_submit wait list
    easy_aio_event_t   event;
    int                ret, cnt, n;
    easy_iocb_t        *iocb[EASY_AIO_MAX_BATCH];
    easy_aio_task_t    *tsk, *tsk2;

    cnt = 0;
    n = easy_min(EASY_AIO_MAX_BATCH, EASY_AIO_MAX_PENDING - aio->pending);
    easy_list_for_each_entry_safe(tsk, tsk2, &aio->list, node) {
        easy_list_del(&tsk->node);
        iocb[cnt++] = &tsk->iocb;

        if (cnt >= n) break;
    }

    // sumbit
    aio->pending += cnt;

    if ((ret = easy_aio_submit(aio->ctx, cnt, iocb)) < 0) {
        easy_error_log("easy_aio_submit error: %d", errno);
        memset(&event, 0, sizeof(event));
        aio->pending -= cnt;

        for(n = 0; n < cnt; n++) {
            tsk = (easy_aio_task_t *) iocb[n]->aio_data;
            event.res = -1;
            (tsk->cb)(&event, tsk->args);
            easy_array_free(aio->arr, tsk);
        }
    } else {
        for(n = ret; n < cnt; n++) {
            tsk = (easy_aio_task_t *) iocb[n]->aio_data;
            easy_list_add_tail(&tsk->node, &aio->list);
            aio->pending --;
        }
    }

    return (ret != cnt);
}

easy_aio_task_t *easy_aio_newtask()
{
    easy_iocb_t        *iocb;
    easy_aio_task_t    *tsk;
    easy_aio_t         *aio = easy_baseth_self->aio;

    tsk = (easy_aio_task_t *) easy_array_alloc(aio->arr);
    tsk->cb = NULL;
    iocb = &tsk->iocb;
    iocb->aio_data = (long) tsk;
    iocb->aio_flags = 1; //IOCB_FLAG_RESFD;
    iocb->aio_resfd = aio->efd;
    iocb->aio_key = 0;
    iocb->aio_reserved1 = 0;
    iocb->aio_reqprio = 0;
    iocb->aio_reserved2 = 0;

    return tsk;
}

int easy_aio_dotask(easy_aio_task_t **tsk, int cnt)
{
    int                i, ret = 0;
    easy_aio_t         *aio = easy_baseth_self->aio;
    easy_iocb_t        *iocb[cnt];

    if (aio == NULL) {
        easy_error_log("no easy_aio_init\n");
        return EASY_ERROR;
    }

    if (cnt > EASY_AIO_MAX_PENDING) {
        easy_error_log("cnt(%d) > EASY_AIO_MAX_PENDING\n", cnt);
        return EASY_ERROR;
    }

    if (aio->cursize >= aio->maxsize) {
        easy_error_log("aio->cursize(%d) >= aio->maxsize(%d)\n", aio->cursize, aio->maxsize);
        return EASY_AGAIN;
    }

    aio->cursize += cnt;
    aio->pending += cnt;

    if (aio->pending <= EASY_AIO_MAX_PENDING) {
        for(i = 0; i < cnt; i++) {
            if (tsk[i]->cb == NULL) {
                easy_error_log("cb is null: %d\n", i);
                goto error_exit;
            }

            iocb[i] = &tsk[i]->iocb;
        }

        if ((ret = easy_aio_submit(aio->ctx, cnt, iocb)) < 0) {
            easy_error_log("easy_aio_submit error: %d\n", errno);
            goto error_exit;
        }
    }

    for(i = ret; i < cnt; i++) {
        easy_list_add_tail(&tsk[i]->node, &aio->list);
        aio->pending --;
    }

    return EASY_OK;
error_exit:
    aio->cursize -= cnt;
    aio->pending -= cnt;
    return EASY_ERROR;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
int easy_aio_init(easy_thread_pool_t *tp, int maxsize)
{
    maxsize = easy_align(maxsize, tp->thread_count) / tp->thread_count;
    easy_baseth_register_once(tp, easy_aio_once_start, (void *)(long)maxsize, 0);
    easy_baseth_register_once(tp, easy_aio_once_end, NULL, 1);
    return EASY_OK;
}

#define easy_aio_taskrw(fd, buf, count, offset, cb, args, cmd)          \
    easy_aio_task_t *tsk = easy_aio_newtask();                          \
    easy_aio_inittask(tsk, cmd, fd, buf, count, offset, cb, args);      \
    int ret = easy_aio_dotask(&tsk, 1);                                 \
    if (ret!= EASY_OK) easy_array_free(easy_baseth_self->aio->arr,tsk); \
    return ret;

int easy_aio_pread(int fd, void *buf, size_t count, off_t offset, easy_aio_callback_pt *cb, void *args)
{
    easy_aio_taskrw(fd, buf, count, offset, cb, args, EIO_CMD_PREAD);
}

int easy_aio_pwrite(int fd, void *buf, size_t count, off_t offset, easy_aio_callback_pt *cb, void *args)
{
    easy_aio_taskrw(fd, buf, count, offset, cb, args, EIO_CMD_PWRITE);
}

int easy_aio_preadv(int fd, const struct iovec *iov, int iovcnt, off_t offset, easy_aio_callback_pt *cb, void *args)
{
    easy_aio_taskrw(fd, iov, iovcnt, offset, cb, args, EIO_CMD_PREADV);
}

int easy_aio_pwritev(int fd, const struct iovec *iov, int iovcnt, off_t offset, easy_aio_callback_pt *cb, void *args)
{
    easy_aio_taskrw(fd, iov, iovcnt, offset, cb, args, EIO_CMD_PWRITEV);
}

#undef easy_aio_taskrw

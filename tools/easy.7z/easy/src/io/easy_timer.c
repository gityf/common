#include <easy/easy_io.h>
#include <easy/easy_timer.h>
#include <easy/easy_connection.h>
#include <easy/easy_socket.h>

int easy_timer_on_process(easy_baseth_t *th, easy_task_t *t)
{
    ev_timer                *watcher;
    easy_timer_exec_pt      *op;

    if ((watcher = (ev_timer *)t->task_args) == NULL) {
        return EASY_ERROR;
    }

    op = (easy_timer_exec_pt *)t->user_data;
    (op)(th->loop, watcher);
    free(t);
    return EASY_OK;
}

int easy_timer_exec(easy_baseth_t *th, ev_timer *watcher, easy_timer_exec_pt *op)
{
    easy_task_t             *t;

    if (th == easy_baseth_self) {
        (op)(th->loop, watcher);
        return EASY_OK;
    }

    if ((t = malloc(sizeof(easy_task_t))) == NULL) {
        return EASY_ERROR;
    }

    t->task_type = EASY_TASK_TYPE_TIMER;
    t->task_args = watcher;
    t->task_process = easy_timer_on_process;
    t->user_data = op;
    easy_baseth_async_lite(th, t);
    return EASY_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
int easy_register_server_fd(easy_io_t *eio, int fd, easy_io_handler_pt *handler)
{
    if (fd < 0)
        return EASY_ERROR;

    int                     index = easy_hash_key(fd);
    easy_task_t            *task = (easy_task_t *) calloc(1, sizeof(easy_task_t));
    easy_baseth_t          *th = (easy_baseth_t *)easy_thread_pool_hash(eio->io_thread_pool, index);

    task->hashkey = fd;
    task->user_data = handler;
    task->task_process = easy_connection_register_one;
    easy_baseth_async_lite(th, task);
    return EASY_OK;
}
int easy_register_listen_fd(easy_io_t *eio, int fd, easy_io_handler_pt *handler)
{
    if (fd < 0)
        return EASY_ERROR;

    easy_addr_t addr;
    int         udp = ((handler && handler->is_udp) ? 1 : 0);
    addr.family = AF_MAX;
    addr.u.addr = fd;

    if (easy_add_listen_addr(eio, addr, handler, udp, 0, NULL) == NULL) {
        return EASY_ERROR;
    }

    return EASY_OK;
}
int easy_register_client_fd(easy_io_t *eio, int fd, easy_io_handler_pt *handler, easy_addr_t *paddr)
{
    easy_addr_t addr;

    memset(&addr, 0, sizeof(addr));
    addr.family = AF_MAX;
    addr.u.addr = fd;
    addr.cidx = (fd << 8);

    if (paddr) memcpy(paddr, &addr, sizeof(addr));

    return easy_connection_connect(eio, addr, handler, EASY_CLIENT_DEFAULT_TIMEOUT, NULL, 0);
}

inline int easy_timeout_queue_update(easy_timeout_queue_t *queue, easy_session_t *s)
{
    if (queue->timeout == s->r_timeout) {
        queue->cnt = (queue->cnt > 20 ? queue->cnt : queue->cnt + 1);
        return 1;
    }

    if (queue->cnt == 0) {
        if (easy_list_empty(&(queue->head)) || queue->timeout < s->r_timeout) {
            queue->timeout = s->r_timeout;
            queue->cnt = 1;
            return 1;
        }
    }

    --(queue->cnt);
    return 0;
}

inline int easy_timeout_queue_addin(easy_timeout_queue_t *q, easy_session_t *s)
{
    if (s->r_timeout != q->timeout || q->cnt == 0) {
        return 0;
    }

    easy_list_add_tail(&(s->timeout_queue_node), &(q->head));

    if ((easy_list_get_first(&(q->head), easy_session_t, timeout_queue_node)) == s && !ev_is_active(&q->timer)) {
        ev_timer_set(&q->timer, 0.0, s->r_timeout / 1000.0);
        ev_timer_start(easy_baseth_self->loop, &(q->timer));
    }

    return 1;
}


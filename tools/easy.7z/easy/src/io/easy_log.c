#include <easy/easy_log.h>
#include <easy/easy_time.h>
#include <pthread.h>
#include <easy/easy_io.h>
#include <sys/syscall.h>
#include <fcntl.h>

easy_log_print_pt       easy_log_print = easy_log_print_default;
easy_log_format_pt      easy_log_format = easy_log_format_default;
easy_log_level_t        easy_log_level = EASY_LOG_WARN;

__thread int  easy_log_oldtime __attribute__ ((tls_model ("initial-exec"))) = 0;
__thread int  easy_log_tid __attribute__ ((tls_model ("initial-exec"))) = 0;
__thread char easy_log_timestr[36] __attribute__ ((tls_model ("initial-exec")));

/**
 * 设置log的打印函数
 */
void  easy_log_set_print(easy_log_print_pt p)
{
    easy_log_print = p;
    ev_set_syserr_cb(easy_log_print);
}

/**
 * 设置log的格式函数
 */
void  easy_log_set_format(easy_log_format_pt p)
{
    if (getenv("easy_log_level") == NULL) {
        easy_log_format = p;
    }
}

static void easy_log_fill_timestr()
{
    time_t                      tsec;
    int                         msec, i;
    char                        *p;
    ev_tstamp                   now;

    // 从loop中取
    if (easy_baseth_self && easy_baseth_self->loop) {
        now = ev_now(easy_baseth_self->loop);
    } else {
        now = ev_time();
    }

    tsec = (int)now;
    msec = (now - tsec) * 1000;

    if (easy_log_oldtime != tsec) {
        easy_log_oldtime = tsec;
        struct tm               tm;

        if (easy_log_tid == 0) easy_log_tid = syscall(SYS_gettid);

        easy_localtime((const time_t *)&tsec, &tm);
        lnprintf(easy_log_timestr, 36, "[%04d-%02d-%02d %02d:%02d:%02d.000] %d",
                 tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
                 tm.tm_hour, tm.tm_min, tm.tm_sec, easy_log_tid);
    }

    p = easy_log_timestr + 24;

    for(i = 0; i < 3; i++) {
        *--p = (char) (msec % 10 + '0');
        msec /= 10;
    }
}

/**
 * 加上日志
 */
void easy_log_format_default(int level, const char *file, int line, const char *function, const char *fmt, ...)
{
    int                         len;
    char                        buffer[4096];

    // 从loop中取
    easy_log_fill_timestr();

    // print
    len = lnprintf(buffer, 128, "%s %s:%d ", easy_log_timestr, file, line);
    va_list                 args;
    va_start(args, fmt);
    len += easy_vsnprintf(buffer + len, 4090 - len,  fmt, args);
    va_end(args);

    // 去掉最后'\n'
    while(buffer[len - 1] == '\n') len --;

    buffer[len++] = '\n';
    buffer[len] = '\0';

    easy_log_print(buffer);
}

/**
 * 打印出来
 */
void easy_log_print_default(const char *message)
{
    easy_ignore(write(2, message, strlen(message)));
}

void __attribute__((constructor)) easy_log_start_()
{
    char                    *p = getenv("easy_log_level");

    fcntl(2, F_SETFL, O_RDWR | O_APPEND | O_SYNC);

    if (p) easy_log_level = (easy_log_level_t)atoi(p);
}


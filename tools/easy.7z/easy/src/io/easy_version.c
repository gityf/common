char *easy_build_time = "LIBEASY VERSION: KEY:1919502551844429923 BUILDTIME:2015-08-03 23:33:06  "
"Revision: BUILDHOST:w@localhost.localdomain/home/w/src/common";
unsigned long long easy_version_key = 1919502551844429923LLU;

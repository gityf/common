#include <easy/easy_io.h>
#include <easy/easy_request.h>
#include <easy/easy_message.h>
#include <easy/easy_connection.h>

static void easy_request_cleanup (easy_buf_t *b, void *args);

/**
 * 对request回复响应
 *
 * @param packet对象
 */
int easy_request_do_reply(easy_request_t *r)
{
    easy_connection_t       *c;
    easy_message_t          *m;

    // encode
    m = (easy_message_t *)r->ms;
    c = m->c;

    if (c->ioth->tid != pthread_self()) {
        easy_fatal_log("r: %p not run at other thread: %lx <> %lx\n", r, pthread_self(), c->ioth->tid);
        return EASY_ERROR;
    }

    if (c->type == EASY_TYPE_CLIENT)
        return EASY_OK;

    easy_list_del(&r->request_list_node);

    if (easy_connection_request_done(r) == EASY_OK) {
        if (easy_list_empty(&c->output) == 0) {
            ev_io_start(c->loop, &c->write_watcher);
        }

        if (m->request_list_count == 0 && m->status != EASY_MESG_READ_AGAIN) {
            return easy_message_destroy(m, 1);
        }
    }

    return EASY_OK;
}

static void easy_request_sended (easy_buf_t *b, void *args)
{
    easy_session_t  *s = (easy_session_t *) args;
    s->send_time = ev_now(s->c->loop);
}

/**
 * push到c->output上
 */
void easy_request_addbuf(easy_request_t *r, easy_buf_t *b)
{
    easy_session_t  *s = (easy_session_t *)r->ms;

    // 在超时的时间用到
    if (s->task_type == EASY_TYPE_SESSION) {
        s->nextb = &b->node;
        easy_buf_set_cleanup(b, easy_request_sended, s);
    }

    s->c->output_bytes += (b->last - b->pos);

    easy_list_add_tail(&b->node, &s->c->output);
}

/**
 * 加list到c->output上
 */
void easy_request_addbuf_list(easy_request_t *r, easy_list_t *list)
{
    easy_buf_t              *b;
    easy_session_t          *s = (easy_session_t *) r->ms;

    // 是否为空
    if (easy_list_empty(list))
        return;

    // 在超时的时间用到
    if (s->task_type == EASY_TYPE_SESSION) {
        if ((b = easy_list_get_last(list, easy_buf_t, node))) {
            s->nextb = &b->node;
            easy_buf_set_cleanup(b, easy_request_sended, s);
        }
    }

    easy_list_for_each_entry(b, list, node) {
        s->c->output_bytes += (b->last - b->pos);
    }

    easy_list_join(list, &s->c->output);
    easy_list_init(list);
}

/**
 * 用于回调, 写完调用server_done
 */
static void easy_request_cleanup (easy_buf_t *b, void *args)
{
    easy_request_t          *r = (easy_request_t *) args;

    if (r->status == EASY_REQUEST_DONE) {
        easy_list_del(&r->all_node);
        easy_list_del(&r->request_list_node);
        easy_request_server_done(r);
    }

    easy_message_destroy((easy_message_t *)r->ms, 0);
}

/**
 * 设置request的cleanup方法
 */
void easy_request_set_cleanup(easy_request_t *r, easy_list_t *output)
{
    easy_buf_t              *b;
    easy_message_session_t  *ms = r->ms;
    b = easy_list_get_last(output, easy_buf_t, node);

    if (ms->task_type == EASY_TYPE_MESSAGE && b) {
        easy_atomic_inc(&ms->pool->ref);
        easy_buf_set_cleanup(b, easy_request_cleanup, r);
    }
}

/**
 * destroy掉easy_request_t对象
 */
void easy_request_server_done(easy_request_t *r)
{
    int                     doing;
    easy_connection_t       *c = r->ms->c;

    if (c->type == EASY_TYPE_SERVER) {
#ifdef EASY_DEBUG_DOING
        EASY_PRINT_BT("doing_request_count_dec:%d,c:%s,r:%p,%ld.", c->doing_request_count, easy_connection_str(c), r, r->uuid);
#endif
#ifdef EASY_DEBUG_MAGIC
        r->magic ++;
#endif

        c->pending_request_count --;

        if (r->istimer) {
            ev_timer_stop(c->loop, &r->timeout_watcher);
        }

        if (r->alone == 0) {
            assert(c->doing_request_count > 0);
            c->doing_request_count --;
            doing = easy_atomic32_add_return(&c->ioth->doing_request_count, -1);
            assert(doing >= 0);
        }

#ifdef SUMMARY_ENABLE

        if (!r->status) c->con_summary->done_request_count ++;

        c->con_summary->rt_total += (ev_time() - r->start_time);
#else

        if (!r->status) c->done_request_count ++;

#endif


        if (c->handler->cleanup) (c->handler->cleanup)(r, NULL);
    }
}

void easy_request_client_done(easy_request_t *r)
{
    easy_connection_t       *c = r->ms->c;
#ifdef EASY_DEBUG_DOING
    EASY_PRINT_BT("doing_request_count_dec:%d,c:%s,r:%p,%ld.", c->doing_request_count, easy_connection_str(c), r, r->uuid);
#endif
#ifdef EASY_DEBUG_MAGIC
    r->magic ++;
#endif
    c->doing_request_count --;
#ifdef SUMMARY_ENABLE
    c->con_summary->doing_request_count --;
    c->con_summary->done_request_count ++;
#else
    c->done_request_count ++;
#endif
    easy_atomic32_dec(&c->ioth->doing_request_count);
}

/**
 * 重新wakeup
 */
void easy_request_wakeup(easy_request_t *r)
{
    if (r) {
        easy_baseth_async_p(r->ms->c->ioth, r, easy_connection_taskresp);
    }
}

/**
 * 引用计数增加,与easy_request_wakeup成对
 */
void easy_request_sleeping(easy_request_t *r)
{
    if (r) {
        // 引用次数
        easy_atomic_inc(&r->ms->c->pool->ref);
        easy_atomic_inc(&r->ms->pool->ref);
        easy_pool_set_lock(r->ms->pool);
    }
}

/**
 * 等这个请求完成，才处理下面的请求
 */
int easy_request_block(easy_request_t *r)
{
    r->block = 1;

    if (r->ms->c->pending_request_count > 1)
        return EASY_BREAK;
    else
        return EASY_OK;
}

/**
 * later process, unit: us
 */
int easy_request_later_process(easy_request_t *r, int64_t us)
{
    double t = (us > 1000 ? us / 1000000.0 : 0.001);
    ev_timer_init(&r->timeout_watcher, easy_connection_on_later, t, 0.0);
    r->istimer = 1;
    r->timeout_watcher.data = r;
    ev_timer_start(easy_baseth_self->loop, &r->timeout_watcher);
    return EASY_AGAIN;
}

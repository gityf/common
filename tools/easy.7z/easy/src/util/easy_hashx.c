#include <easy/easy_hashx.h>
#include <stdlib.h>

static uint32_t easy_hashx_getm(uint32_t size);

/**
 * 创建一easy_hashx_t
 */
easy_hashx_t *easy_hashx_create(uint32_t size, int offset)
{
    easy_hashx_t            *table;
    uint32_t                n = easy_hashx_getm(size);

    // alloc
    table = (easy_hashx_t *)malloc(sizeof(easy_hashx_t));

    if (table == NULL)
        return NULL;

    table->buckets = (easy_hashx_node_t **)malloc(n * sizeof(easy_hashx_node_t *));

    if (table->buckets == NULL) {
        free(table);
        return NULL;
    }

    memset(table->buckets, 0, n * sizeof(easy_hashx_node_t *));
    table->size = n;
    table->mask = n - 1;
    table->count = 0;
    table->offset = offset;
    return table;
}

int easy_hashx_resize(easy_hashx_t *table)
{
    uint32_t                 org_size, i;
    easy_hashx_node_t        **org_buckets;
    easy_hashx_node_t        *node, *n;

    org_buckets = table->buckets;
    org_size    = table->size;
    table->size *= 2;
    table->mask = table->size - 1;
    table->buckets = (easy_hashx_node_t **)malloc(table->size * sizeof(easy_hashx_node_t *));
    memset(table->buckets, 0, table->size * sizeof(easy_hashx_node_t *));

    if (table->buckets == NULL)
        return EASY_ERROR;

    for(i = 0; i < org_size; ++i) {
        for(node = org_buckets[i]; node; node = n) {
            n = node->next;
            _easy_hashx_add(table, node->key, node);
        }
    }

    free(org_buckets);
    return EASY_OK;
}

inline void _easy_hashx_add(easy_hashx_t *table, uint64_t key, easy_hashx_node_t *node)
{
    uint64_t                n;
    easy_hashx_node_t       *first;

    n = easy_hash_key(key);
    n &= table->mask;

    node->key = key;
    first = table->buckets[n];
    node->next = first;

    if (first)
        first->pprev = &node->next;

    table->buckets[n] = node;
    node->pprev = &(table->buckets[n]);
}

int easy_hashx_add(easy_hashx_t *table, uint64_t key, easy_hashx_node_t *node)
{

    if (table->count >= table->size * LOAD_FACTOR && easy_hashx_resize(table) != EASY_OK)
        return EASY_ERROR;

    _easy_hashx_add(table, key, node);
    ++table->count;

    return EASY_OK;
}

void *easy_hashx_find(easy_hashx_t *table, uint64_t key)
{
    uint64_t                n;
    easy_hashx_node_t        *node;

    n = easy_hash_key(key);
    n &= table->mask;

    for(node = table->buckets[n]; node; node = node->next) {
        if(node->key == key)
            return ((char *)node - table->offset);
    }

    return NULL;
}

void *easy_hashx_find_ex(easy_hashx_t *table, uint64_t key, easy_hashx_cmp_pt cmp, const void *a)
{
    uint64_t                n;
    easy_hashx_node_t        *node;

    n = easy_hash_key(key);
    n &= table->mask;

    for(node = table->buckets[n]; node; node = node->next) {
        if (cmp(a, ((char *)node - table->offset)) == 0)
            return ((char *)node - table->offset);
    }

    return NULL;
}

void easy_hashx_clear(easy_hashx_t *table)
{
    int                     i;
    easy_hashx_node_t       *node;

    for(i = 0; i < table->size; ++i) {
        if ((node = table->buckets[i])) {
            node->pprev = NULL;
        }

        table->buckets[i] = NULL;
    }

    table->count = 0;
}

void *easy_hashx_del(easy_hashx_t *table, uint64_t key)
{
    uint64_t                n;
    easy_hashx_node_t        *node;

    n = easy_hash_key(key);
    n &= table->mask;

    for(node = table->buckets[n]; node; node = node->next) {
        if(node->key == key) {
            easy_hashx_del_node(node);
            table->count --;
            return ((char *)node - table->offset);
        }
    }

    return NULL;
}

int easy_hashx_del_node(easy_hashx_node_t *node)
{
    easy_hashx_node_t        *next, **pprev;

    if (!node->pprev)
        return 0;

    next = node->next;
    pprev = node->pprev;
    *pprev = next;

    if (next) next->pprev = pprev;

    node->next = NULL;
    node->pprev = NULL;

    return 1;
}

void easy_hashx_destroy(easy_hashx_t *table)
{
    if(table) {
        easy_hashx_clear(table);
        free(table->buckets);
        free(table);
    }
}

static uint32_t easy_hashx_getm(uint32_t size)
{
    uint32_t                n = 4;
    size &= 0x7fffffff;

    while(size > n) n <<= 1;

    return n;
}

#include <easy/easy_uthread.h>

#define defreg(name) \
    if (strcmp(p, "reg_" #name) == 0) { ptr += snprintf(ptr, 32, "0x%x(", (int)offsetof(easy_ucontext_t, name));} \
    if (strcmp(p, "reg_O" #name) == 0) { ptr += snprintf(ptr, 32, "0x%x(", (int)offsetof(easy_uthread_t, context.name));}
#define defeu(name, value) if (strcmp(p, "reg_O" #name) == 0) { ptr += snprintf(ptr, 32, "0x%x(", (int)offsetof(easy_uthread_t, value));}
void replace_reg(char *buffer)
{
    char nbuf[1024], *ptr;
    char *p = strstr(buffer, "reg_");

    if (p == NULL) return;

    char *q = strchr(p, '(');

    if (q == NULL) return;

    *q = '\0';
    ptr = easy_memcpy(nbuf, buffer, p - buffer);
    defreg(rdi);
    defreg(rsi);
    defreg(rdx);
    defreg(rcx);
    defreg(r8);
    defreg(r9);
    defreg(rax);
    defreg(rbx);
    defreg(rbp);
    defreg(r10);
    defreg(r11);
    defreg(r12);
    defreg(r13);
    defreg(r14);
    defreg(r15);
    defreg(rsp);
    defreg(rip);
    defeu(args, task_args);
    defeu(args2, task_args2);
    defeu(process, task_process);
    defeu(exiting, exiting);
    ptr += snprintf(ptr, 1024, "%s", q + 1);
    memcpy(buffer, nbuf, ptr - (char *)nbuf + 1);
}

int main(int argc, char *argv[])
{
    if (argc < 3) return -1;

    FILE *sfp = NULL, *dfp = NULL;

    sfp = fopen(argv[1], "rb");

    if (sfp == NULL) goto error_exit;

    dfp = fopen(argv[2], "wb");

    if (dfp == NULL) goto error_exit;

    char buffer[1024];

    while(fgets(buffer, 1024, sfp)) {
        replace_reg(buffer);
        fprintf(dfp, "%s", buffer);
    }

    fclose(dfp);
    fclose(sfp);
    return 0;

error_exit:

    if (sfp) fclose(sfp);

    if (dfp) fclose(dfp);

    return -1;
}

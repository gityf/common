#include <easy/easy_atomic.h>
#include <easy/easy_uthread.h>
#include <malloc.h>
#include <sys/mman.h>
#include <sys/syscall.h>

#define EASY_PAGESIZE          4096
#define EASY_UTHREAD_STACK     (EASY_PAGESIZE*16)
#define EASY_UTHREAD_RESERVE   (128)
#define EASY_UTHREAD_STSIZE    (sizeof(easy_uthread_t) + EASY_PAGESIZE + EASY_UTHREAD_RESERVE)

/**
 * 用户态线程
 */

__thread easy_uthread_control_t *easy_uthread_var __attribute__ ((tls_model ("initial-exec"))) = NULL;

static void easy_uthread_free_stack(easy_uthread_control_t *euc, easy_uthread_t *t);
static void easy_uthread_needstack(easy_uthread_control_t *euc, int n);
static easy_uthread_t *easy_uthread_alloc_stack(easy_uthread_control_t *euc, int stack_size);
static void easy_uthread_run(easy_uthread_control_t *euc, easy_uthread_t *t);

/**
 * 需要初始化一下
 */
void easy_uthread_init(easy_uthread_control_t *control)
{
    if (easy_uthread_var == NULL) {
        memset(control, 0, sizeof(easy_uthread_control_t));
        control->tid = syscall(SYS_gettid);
        easy_list_init(&control->runqueue);
        easy_list_init(&control->thread_list);
        easy_uthread_var = control;
    }
}

/**
 * 释放掉所有资源
 */
void easy_uthread_destroy()
{
    easy_uthread_t          *t, *t2;
    easy_uthread_control_t  *euc;

    if (!(euc = easy_uthread_var))
        return;

    easy_list_for_each_entry_safe(t, t2, &euc->thread_list, thread_list_node) {
        if (t->protect) mprotect(t->buffer, EASY_PAGESIZE, PROT_READ | PROT_WRITE);

        free(t->buffer);
    }
    t = euc->nbuf_list;

    while (t) {
        t2 = (easy_uthread_t *)t->thread_list_node.next;

        if (t->protect) mprotect(t->buffer, EASY_PAGESIZE, PROT_READ | PROT_WRITE);

        free(t->buffer);
        t = t2;
    }

    easy_uthread_var = NULL;
}

/**
 * 退出线程数
 */
void easy_uthread_exit()
{
    easy_uthread_var->running->exiting = 1;
    easy_uthread_switch();
}

/**
 * 切换给其他CPU
 */
void easy_uthread_switch()
{
    easy_uthread_control_t *euc = easy_uthread_var;
    easy_uthread_t         *t = euc->running;

    easy_uthread_needstack(euc, 0);
    easy_swapcontext(&t->context, &euc->context);
}

/**
 * 得到当前正常运行的easy_uthread_t
 */
easy_uthread_t *easy_uthread_current()
{
    easy_uthread_control_t *euc = easy_uthread_var;
    return (euc ? euc->running : NULL);
}

uint64_t easy_uthread_id()
{
    uint64_t id = 0;
    easy_uthread_control_t *euc = easy_uthread_var;

    if (euc && euc->running) {
        id = euc->running->tid;
        id <<= 32;
        id |= euc->running->coid;
    }

    return id;
}

/**
 * stack检查.
 */
void easy_uthread_needstack(easy_uthread_control_t *euc, int n)
{
    easy_uthread_t *t = euc->running;

    if((char *)&t <= (char *)t->buffer || (char *)&t >= (char *)t) {
        fprintf(stderr, "uthread stack overflow: &t=%p stk=%p t=%p\n", &t, t->buffer, t);
        abort();
    }
}

/**
 * 准备就绪, 加入到运行队列中
 */
void easy_uthread_ready(easy_uthread_t *t)
{
    if (t) {
        t->ready = 1;
        easy_list_add_tail(&t->task_list_node, &easy_uthread_var->runqueue);
    }
}

/**
 * 打印出uthread信息
 */
void easy_uthread_print(int sig)
{
    easy_uthread_t          *t;
    char                    *extra;
    easy_uthread_control_t  *euc = easy_uthread_var;

    fprintf(stderr, "uthread list:\n");
    easy_list_for_each_entry(t, &euc->thread_list, thread_list_node) {
        if(t == euc->running)
            extra = " (running)";
        else if(t->ready)
            extra = " (ready)";
        else
            extra = " (idle)";

        fprintf(stderr, "uthread %d:%d %s\n", t->tid, t->coid, extra);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * 用于ev_loop
 */
void easy_uthread_loop_yield(easy_uthread_control_t *euc)
{
    easy_uthread_t          *t;

    while (easy_list_empty(&euc->runqueue) == 0) {
        t = easy_list_entry(euc->runqueue.next, easy_uthread_t, task_list_node);
        easy_list_del(&t->task_list_node);
        easy_uthread_run(euc, t);
    }
}

static void easy_uthread_run(easy_uthread_control_t *euc, easy_uthread_t *t)
{
    t->ready = 0;
    euc->running = t;
    easy_swapcontext(&euc->context, &t->context);
    euc->running = NULL;

    if(t->exiting) {
        easy_list_del(&t->thread_list_node);
        euc->thread_count --;
        easy_uthread_free_stack(euc, t);
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////
static easy_uthread_t *easy_uthread_alloc_stack(easy_uthread_control_t *euc, int stack_size)
{
    int             size;
    easy_uthread_t *t = NULL;
    unsigned char  *buffer;

    // default
    size = stack_size + EASY_UTHREAD_STSIZE;

    if (size == EASY_UTHREAD_STSIZE) {
        size = EASY_UTHREAD_STACK;

        if (euc->nbuf_list) {
            t = euc->nbuf_list;
            euc->nbuf_list = (easy_uthread_t *)t->thread_list_node.next;
        }
    } else {
        size = easy_align(size, EASY_PAGESIZE);
    }

    euc->coid ++;

    if (t) {
        t->tid = euc->tid;
        t->coid = euc->coid;
        *(int16_t *)(&t->task_type) = 0;
        return t;
    }

    if ((buffer = (unsigned char *)memalign(EASY_PAGESIZE, size)) == NULL)
        return NULL;

    // 初始化
    t = (easy_uthread_t *)(buffer + size - sizeof(easy_uthread_t));
    memset(t, 0, sizeof(easy_uthread_t));
    t->buffer = buffer;
    t->size = size;
    t->tid = euc->tid;
    t->coid = euc->coid;
    t->threadptr = euc->threadptr;

    if (++ euc->bufcnt < 1024) {
        t->protect = 1;
        mprotect(buffer, EASY_PAGESIZE, PROT_NONE);
    }

    return t;
}

static void easy_uthread_free_stack(easy_uthread_control_t *euc, easy_uthread_t *t)
{
    if (t->protect) {
        t->thread_list_node.next = (easy_list_t *)euc->nbuf_list;
        euc->nbuf_list = t;
    } else {
        free(t->buffer);
    }
}

int easy_uthread_exec(easy_uthread_control_t *euc, easy_uthread_start_pt *fn, void *args, void *args2)
{
    easy_uthread_t *t = NULL;

    if ((t = easy_uthread_alloc_stack(euc, 0)) == NULL) {
        return EASY_ERROR;
    }

    t->task_process = fn;
    t->task_args = args;
    t->task_args2 = args2;
    euc->thread_count ++;
    euc->running = t;
    easy_list_add_tail(&t->thread_list_node, &euc->thread_list);

    long *sp = (long *) (t->buffer + t->size + EASY_PAGESIZE - EASY_UTHREAD_STSIZE);
    sp[0] = (long)easy_context_start;
    sp[1] = (long)easy_uthread_exit;
    sp[2] = 0;
    easy_gocontext(t, sp, &euc->context);
    euc->running = NULL;

    if (t->exiting) {
        easy_list_del(&t->thread_list_node);
        euc->thread_count --;
        easy_uthread_free_stack(euc, t);
    }

    return EASY_OK;
}


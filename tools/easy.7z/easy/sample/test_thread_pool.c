#include <easy/easy_io.h>

easy_thread_pool_t *gtp = NULL;
int stoped = 0;
typedef struct {
    int64_t rcnt;
    int64_t scnt;
    int64_t align[6];
} grstat;
grstat gs[10];

int request_process(easy_baseth_t *th, easy_task_t *r)
{
    ((grstat *)th->args)->rcnt ++;
    easy_list_add_tail(&r->task_list_node, (easy_list_t *)r->user_data);
    return EASY_ABORT;
}

int send_process(easy_baseth_t *th, easy_task_t *rx)
{
    easy_task_t *r;
    int i;
    easy_baseth_t *ioth = easy_baseth_self;
    grstat *gt = &gs[ioth->idx];
    ioth->args = (void *) gt;
    easy_list_t list;
    easy_list_init(&list);
    r = (easy_task_t *) calloc(1000, sizeof(easy_task_t));

    for(i = 0; i < 1000; i++) {
        r[i].user_data = &list;
        easy_list_add_tail(&(r[i].task_list_node), &list);
    }

    while(1) {
        while (easy_list_empty(&list)) {
            easy_coroutine_usleep(1);
        }

        r = easy_list_get_first(&list, easy_task_t, task_list_node);
        easy_list_del(&r->task_list_node);
        easy_coroutine_process_set(r, request_process);
        easy_baseth_async_lite(ioth, r);
        gt->scnt ++;
    }

    stoped = 1;
    return EASY_ABORT;
}

int main(int argc, char **argv)
{
    int cnt = 1;
    int i;

    if (argc > 1) cnt = atoi(argv[1]);

    fprintf(stderr, "easy_uthread_t: %ld, %ld\n", sizeof(easy_uthread_t), sizeof(easy_coroutine_thread_t));
    // start
    ev_set_allocator(easy_pool_realloc);
    easy_pool_t *pool = easy_pool_create(0);
    pool->flags = 1;
    easy_io_t *eio = (easy_io_t *)easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->started = 1;
    eio->pool = pool;
    easy_list_init(&eio->thread_pool_list);
    gtp = easy_coroutine_pool_create(eio, cnt, request_process, NULL);
    easy_baseth_pool_start(gtp);

    // start send
    int64_t start = easy_time_now();

    for(i = 0; i < cnt; i++) {
        easy_task_t *r = (easy_task_t *) calloc(1, sizeof(easy_task_t));
        r->istask = 1;
        r->user_data = NULL;
        easy_coroutine_process_set(r, send_process);
        easy_thread_pool_addin(gtp, r, i);
    }

    while(stoped == 0) {
        sleep(1);
        int64_t end = easy_time_now();
        int64_t rcnt = 0;
        int64_t scnt = 0;

        for(i = 0; i < cnt; i++) {
            rcnt += gs[i].rcnt;
            scnt += gs[i].scnt;
        }

        double speed = rcnt * 1000000.0 / (end - start);
        fprintf(stderr, "QPS: %.2f, pending: %ld.\r", speed, scnt - rcnt);
    }

    easy_baseth_pool_stop(gtp);
    easy_baseth_pool_wait(gtp);
    easy_baseth_pool_destroy(gtp);
    return 0;
}


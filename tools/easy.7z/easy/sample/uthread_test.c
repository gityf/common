#include <stdio.h>
#include <easy/easy_io.h>
#include <easy/easy_uthread.h>

extern int easy_swapcontext(ucontext_t *from, ucontext_t *to);
extern int easy_getcontext(ucontext_t *from);
easy_uthread_control_t ctrl;
easy_uthread_t *pcur = NULL;

int test(int i)
{
    void *ra = __builtin_extract_return_addr (__builtin_return_address (0));
    int a = 0;
    fprintf(stderr, "\n>>>>>>>i=%d Start: %p, pcur:%p: ra:%p\n", i, &a, pcur, ra);

    if (pcur == NULL) {
        //    EASY_PRINT_BT("test.");
        pcur = easy_uthread_current();

        if (pcur == NULL) {
            pcur = easy_uthread_clone();
            easy_uthread_swnext(pcur);
        } else {
            easy_uthread_switch();
        }

        fprintf(stderr, "i=%d Done\n", i);
        fflush(stderr);
        int x = random();
        a += x;
    } else if (pcur != NULL) {
        easy_uthread_ready(pcur);
        pcur = NULL;
    }

    return a;
    //fprintf(stderr, "i=%d End.\n", i);
}

void testrun(easy_uthread_control_t *euc, int x, int y)
{
    int f = x;
    fprintf(stderr, "F: %p testrun\n", &f);
    test(f);
}

void test_wakeup()
{
    easy_atomic_t i = 0;

    EASY_UTHREAD_STACKTOP(&ctrl);
    fprintf(stderr, "TTTi=%ld\n", i);

    while(++i <= 10) {
        testrun(&ctrl, i, 0);
    }
}

int main(int argc, char *argv[])
{
    fprintf(stderr, "easy_uthread_t: %d\n", (int)sizeof(easy_uthread_t));
    easy_uthread_init(&ctrl);
    test_wakeup();
    easy_uthread_loop_yield(&ctrl);
    easy_uthread_destroy();

    return 0;
}

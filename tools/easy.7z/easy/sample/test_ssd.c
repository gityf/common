#include <easy/easy_io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#define CHUNK_SIZE (64*1024*1024)
typedef struct test_ioev_t test_ioev_t;
typedef struct test_thread_t test_thread_t;
typedef struct test_ssd_t test_ssd_t;

struct test_ssd_t {
    int thread_cnt;
    int iodepth;
    int diskcnt;
    int chunkcnt;
    test_thread_t *ts[64];
    easy_atomic_t stop;
    int mode;
};

struct test_thread_t {
    test_ssd_t *tst;
    test_ioev_t *ioev;
    uint64_t donecnt;
    uint64_t failcnt;
    uint64_t fcnt;
    int fds[0];
};

struct test_ioev_t {
    test_thread_t *t;
    char *buffer;
    uint64_t hcode;
    int  index;
    int  fd;
    uint64_t offset;
};

int mode1_open(easy_baseth_t *th, void *args);
int mode1_close(easy_baseth_t *th);
int tesst_ssd_init()
{
    char filename[128];
    struct stat st;
    int index = 0;

    while(index < 11) {
        snprintf(filename, 128, "/apsarapangu/disk%d", index + 1);

        if (stat(filename, &st)) break;

        index ++;
    }

    return index;
}


void mode1_write_callback(easy_aio_event_t *ev, void *args)
{
    test_ioev_t *ioev = (test_ioev_t *) args;

    ioev->t->donecnt ++;

    if (ev->res != 4096) {
        easy_error_log("ev->res:%ld fd:%d, buffer:%p, offset:%ld\n", ev->res, ioev->fd, ioev->buffer, ioev->offset);
        exit(1);
        ioev->t->failcnt ++;
    }

    ioev->hcode = easy_hash_key(ioev->hcode);
    ioev->fd = ioev->t->fds[ioev->hcode % ioev->t->fcnt];
    ioev->offset = easy_align(ioev->hcode % CHUNK_SIZE, 512);
    int ret = easy_aio_pwrite(ioev->fd, ioev->buffer, 4096, ioev->offset, mode1_write_callback, ioev);

    if (ret != EASY_OK) abort();
}

int mode1_write_process(easy_baseth_t *th, easy_task_t *r)
{
    if (mode1_open(th, r->user_data) != EASY_OK) return EASY_ABORT;

    test_thread_t *t = (test_thread_t *)th->args;
    test_ioev_t *ioev = NULL;
    int len = t->tst->iodepth * (sizeof(test_ioev_t) + 4096) + 4096;
    t->ioev = (test_ioev_t *)malloc(len);
    char *ptr = (char *)t->ioev +  t->tst->iodepth * sizeof(test_ioev_t);
    ptr = (char *)easy_align_ptr(ptr, 4096);

    // write
    int i;

    for(i = 0; i < t->tst->iodepth; i ++) {
        ioev = &t->ioev[i];
        memset(ioev, 0, sizeof(test_ioev_t));
        ioev->t = t;
        memset(ptr, 'A', 4096);
        ioev->buffer = ptr;
        ptr += 4096;
        ioev->index = i;
        ioev->hcode = easy_hash_key(i + 1);
        ioev->fd = t->fds[ioev->hcode % t->fcnt];
        ioev->hcode = easy_hash_key(ioev->hcode);
        ioev->offset = easy_align(ioev->hcode % CHUNK_SIZE, 512);
        int ret = easy_aio_pwrite(ioev->fd, ioev->buffer, 4096, ioev->offset, mode1_write_callback, ioev);

        if (ret != EASY_OK) abort();
    }

    free(r);
    return EASY_ABORT;
}

int mode1_open(easy_baseth_t *th, void *args)
{
    if (th->args) abort();

    test_ssd_t *tst = (test_ssd_t *) args;
    int diskcnt = tst->diskcnt;
    int startindex = 0;

    if ((tst->mode & 0xff) == 1) {
        diskcnt = 1;
        startindex = th->idx;
    }

    int l = sizeof(test_thread_t) + tst->chunkcnt * diskcnt * sizeof(int);
    test_thread_t *t = (test_thread_t *)malloc(l);
    memset(t, 0, l);
    t->tst = tst;
    t->fcnt = tst->chunkcnt * diskcnt;

    int i = 0;
    char filename[128];
    char data[8192 + 1024];
    char *ptr = (char *)easy_align_ptr(data, 512);
    memset(ptr, 'A', 8192);

    for(i = 0; i < t->fcnt; i++) {
        int index = i / tst->chunkcnt + 1 + startindex;
        int cnt = i % tst->chunkcnt + 1;
        snprintf(filename, 128, "/apsarapangu/disk%d/.test_ssd_%03d", index, cnt);
        int fd = open(filename, O_CREAT | O_RDWR | O_DIRECT, 0666);

        if (fd < 0) {
            easy_error_log("open fail: %s %s\n", filename, strerror(errno));
            abort();
        }

        t->fds[i] = fd;

        if (tst->mode == 257) {
            int64_t offset = 0;

            while(offset < CHUNK_SIZE) {
                if (pwrite(fd, ptr, 8192, offset) != 8192) {
                    abort();
                }

                offset += 8192;
            }

            fprintf(stderr, "fill: %s Done\n", filename);
        }
    }

    fprintf(stderr, "fcnt: %ld\n", t->fcnt);
    th->args = t;
    tst->ts[th->idx] = t;

    if (tst->mode == 257) {
        mode1_close(th);
        return EASY_ERROR;
    }

    return EASY_OK;
}

int mode1_close(easy_baseth_t *th)
{
    test_thread_t *t = (test_thread_t *)th->args;
    int i;

    for(i = 0; i < t->fcnt; i++) {
        if (t->fds[i] > 0) close(t->fds[i]);
    }

    th->args = NULL;
    free(t);
    return EASY_OK;
}

void *mode1_print_stat(void *args)
{
    test_ssd_t *tst = (test_ssd_t *) args;
    int64_t start = easy_time_now();
    int64_t qps = 0;
    int64_t odone = 0;
    int i;

    while(tst->stop == 0) {
        sleep(1);
        int64_t end = easy_time_now();
        int64_t done = 0;
        int64_t fail = 0;

        for(i = 0; i < tst->thread_cnt; i++) {
            if (tst->ts[i]) {
                done += tst->ts[i]->donecnt;
                fail += tst->ts[i]->failcnt;
            }
        }

        int64_t q = (done - odone) * 1000000 / (end - start);
        qps = (qps + q) / 2;
        fprintf(stderr, "QPS: %ld, fail: %ld, done:%ld\n", qps, fail, done);
        fflush(stderr);
        start = end;
        odone = done;
    }

    return (void *)NULL;
}

int test_ssd_mode1(test_ssd_t *tst)
{
    easy_pool_t         *pool;
    easy_io_t           *eio;

    pool = easy_pool_create(0);
    eio = easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->pool = pool;
    eio->started = 1;
    easy_list_init(&eio->thread_pool_list);

    easy_thread_pool_t *tp = easy_coroutine_pool_create(eio, tst->thread_cnt, mode1_write_process, NULL);
    easy_aio_init(tp, 5000);
    easy_baseth_pool_start(tp);

    // send process
    int i;

    for(i = 0; i < tst->thread_cnt; i++) {
        easy_task_t *t = (easy_task_t *) malloc(sizeof(easy_task_t));
        memset(t, 0, sizeof(easy_task_t));
        t->user_data = tst;
        easy_thread_pool_addin(tp, t, i);
    }

    pthread_t tid;
    pthread_create(&tid, NULL, mode1_print_stat, tst);

    pthread_join(tid, NULL);
    easy_baseth_pool_wait(tp);
    easy_baseth_pool_destroy(tp);

    easy_pool_destroy(pool);

    return 0;
}

int main(int argc, char **argv)
{
    test_ssd_t tst;
    memset(&tst, 0, sizeof(tst));
    tst.thread_cnt = 8;
    tst.iodepth = 16;
    tst.chunkcnt = tst.thread_cnt * 4;

    if (argc > 1) tst.mode = atoi(argv[1]);

    tst.diskcnt = tesst_ssd_init();

    if (tst.diskcnt == EASY_ERROR) {
        return -1;
    }

    if ((tst.mode & 0xff) == 1) tst.thread_cnt = tst.diskcnt;

    test_ssd_mode1(&tst);
    return 0;
}


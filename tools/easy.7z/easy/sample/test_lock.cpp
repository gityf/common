#include <easy/easy_io.h>
#include "mutex_table.h"

easy_thread_pool_t *gtp = NULL;
easy_atomic_t      gscnt = 0;
easy_atomic_t      grcnt = 0;
easy_atomic_t      gacnt = 0;
int stoped = 0;
#define MAX_NUM 30
apsara::MutexTable<uint32_t> mChunkLockTable(128);
uint32_t pendingCount[MAX_NUM];

int request_process(easy_baseth_t *th, easy_task_t *r)
{
    uint64_t idx = easy_hash_key(r->reserved) % MAX_NUM;
    apsara::ScopedLockInTable<uint32_t> lock(mChunkLockTable, idx);
    pendingCount[idx] ++;

    free(r);
    easy_atomic_inc(&grcnt);
    return EASY_ABORT;
}

void *send_request(void *args)
{
    int loop = 0;

    while(stoped == 0) {
        easy_atomic_inc(&gscnt);
        easy_task_t *r = (easy_task_t *) calloc(1, sizeof(easy_task_t));
        r->reserved = rand();
        r->istask = 1;
        r->user_data = NULL;
        easy_thread_pool_addin(gtp, r, (long)r);

        while (gscnt - grcnt > 1000) {
            uint64_t idx = easy_hash_key(grcnt) % MAX_NUM;
            apsara::ScopedLockInTable<uint32_t> lock(mChunkLockTable, idx);
            pendingCount[idx] ++;
            easy_atomic_inc(&gacnt);
        }
    }

    return (void *)NULL;
}

int main(int argc, char **argv)
{
    int scnt = 4;
    int rcnt = 4;
    int i;

    for(int i = 0; i < MAX_NUM; i++) {
        pendingCount[i] = 0;
    }

    if (argc > 1) scnt = atoi(argv[1]);

    if (argc > 2) rcnt = atoi(argv[2]);

    // start
    ev_set_allocator(easy_pool_realloc);
    easy_pool_t *pool = easy_pool_create(0);
    pool->flags = 1;
    easy_io_t *eio = (easy_io_t *)easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->started = 1;
    eio->pool = pool;
    easy_list_init(&eio->thread_pool_list);
    gtp = easy_coroutine_pool_create(eio, rcnt, request_process, NULL);

    // start send
    int64_t start = easy_time_now();
    pthread_t tid[scnt];

    for(i = 0; i < scnt; i++) {
        pthread_create(&tid[i], NULL, send_request, (void *)(long)i);
    }

    i = 0;

    while(stoped == 0) {
        sleep(1);
        int64_t end = easy_time_now();
        double speed = grcnt * 1000000.0 / (end - start);
        fprintf(stderr, "QPS: %.2f, pending: %ld.\r", speed, gscnt - grcnt);

        if (i ++ > 15) stoped = 1;
    }

    for(i = 0; i < scnt; i++) {
        pthread_join(tid[i], NULL);
    }

    easy_baseth_pool_stop(gtp);
    easy_baseth_pool_wait(gtp);
    easy_baseth_pool_destroy(gtp);

    // pendingCount
    int64_t tt = 0;

    for(int i = 0; i < MAX_NUM; i++) {
        tt += pendingCount[i];

        if (pendingCount[i]) fprintf(stderr, "%d => %d\n", i, pendingCount[i]);
    }

    fprintf(stderr, "pending: %ld, recv: %ld\n", tt, grcnt + gacnt);
    fflush(stderr);
    return 0;
}


#include <easy/easy_io.h>
#include <pthread.h>

easy_thread_pool_t *gtp = NULL;
int stoped = 0;
typedef struct {
    int64_t rcnt;
    int64_t scnt;
    easy_baseth_t *th;
    pthread_t tid;
    easy_atomic_t lock;
    int64_t align[4];
} grstat;

typedef struct {
    grstat      *gt;
    easy_list_t *list;
    easy_task_t task;
} test_request_t;

int request_process(easy_baseth_t *th, easy_task_t *r)
{
    test_request_t *tr = (test_request_t *) r->user_data;
    grstat *gt = tr->gt;
    easy_spin_lock(&gt->lock);
    tr->gt->rcnt ++;
    easy_list_add_tail(&r->task_list_node, tr->list);
    easy_spin_unlock(&gt->lock);
    return EASY_ABORT;
}

void *send_process(void *args)
{
    test_request_t *tr;
    easy_task_t *r;
    int i;
    grstat *gt = (grstat *) args;
    gt->th->args = (void *) gt;
    easy_list_t list;
    easy_list_init(&list);
    tr = (test_request_t *) calloc(1000, sizeof(test_request_t));

    for(i = 0; i < 1000; i++) {
        tr[i].gt = gt;
        tr[i].task.user_data = &tr[i];
        tr[i].list = &list;
        easy_list_add_tail(&(tr[i].task.task_list_node), &list);
    }

    int64_t idx = 0;

    while(1) {
        while (easy_list_empty(&list)) {
            usleep(1);
        }

        easy_spin_lock(&gt->lock);
        r = easy_list_get_first(&list, easy_task_t, task_list_node);
        easy_list_del(&r->task_list_node);
        easy_spin_unlock(&gt->lock);
        easy_thread_pool_addin(gtp, r, idx++);
        gt->scnt ++;
    }

    stoped = 1;
    return (void *)NULL;
}

int main(int argc, char **argv)
{
    int cnt = 1;
    int i;

    if (argc > 1) cnt = atoi(argv[1]);

    fprintf(stderr, "easy_uthread_t: %ld, %ld\n", sizeof(easy_uthread_t), sizeof(easy_coroutine_thread_t));
    // start
    ev_set_allocator(easy_pool_realloc);
    easy_pool_t *pool = easy_pool_create(0);
    pool->flags = 1;
    easy_io_t *eio = (easy_io_t *)easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->started = 1;
    eio->pool = pool;
    easy_list_init(&eio->thread_pool_list);
    gtp = easy_coroutine_pool_create(eio, cnt, request_process, NULL);
    easy_baseth_pool_start(gtp);

    // start send
    int64_t start = easy_time_now();
    grstat gs[cnt];

    for(i = 0; i < cnt; i++) {
        memset(&gs[i], 0, sizeof(gs[i]));
        gs[i].th = (easy_baseth_t *)easy_thread_pool_hash(gtp, i);
        pthread_create(&gs[i].tid, NULL, send_process, &gs[i]);
    }

    while(stoped == 0) {
        sleep(1);
        int64_t end = easy_time_now();
        int64_t rcnt = 0;
        int64_t scnt = 0;

        for(i = 0; i < cnt; i++) {
            rcnt += gs[i].rcnt;
            scnt += gs[i].scnt;
        }

        double speed = rcnt * 1000000.0 / (end - start);
        fprintf(stderr, "QPS: %.2f, pending: %ld.\r", speed, scnt - rcnt);
    }

    easy_baseth_pool_stop(gtp);
    easy_baseth_pool_wait(gtp);
    easy_baseth_pool_destroy(gtp);
    return 0;
}


#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

int socket_set_opt(int fd, int option, int value)
{
    return setsockopt(fd, SOL_SOCKET, option, (void *)&value, sizeof(value));
}

int main(int argc, char *argv[])
{
    if (argc != 5 && argc != 3) {
        fprintf(stderr, "%s serverhost serverport\n", argv[0]);
        fprintf(stderr, "%s serverhost serverport localport port_count\n", argv[0]);
        return 1;
    }

    const char *host = argv[1];
    int port = atoi(argv[2]);
    int pfrom = 3000;
    int pto = 3032;
    int i;
    int cnt = 0;
    int fail = 0;
    struct sockaddr_in in;

    if (argc == 5) {
        pfrom = atoi(argv[3]);
        pto = atoi(argv[4]) + pfrom;
    }

    for(i = pfrom; i < pto; i++) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        socket_set_opt(fd, SO_REUSEADDR, 1);
        memset(&in, 0, sizeof(in));
        in.sin_family = AF_INET;
        int ret = -1;

        in.sin_addr.s_addr = inet_addr("0.0.0.0");
        in.sin_port = htons(i);
        ret = bind(fd, (struct sockaddr *)&in, sizeof(in));

        if (ret) continue;

        in.sin_addr.s_addr = inet_addr(host);
        in.sin_port = htons(port);
        struct timeval timeout = {1, 0};
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(struct timeval));
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(struct timeval));
        ret = connect(fd, (struct sockaddr *)&in, sizeof(in));

        if (ret) {
            fprintf(stdout, "%d. localport:%d => %s:%d ERROR:%d\n", ++cnt, i, host, port, errno);
            fail ++;
        } else {
            fprintf(stdout, "%d. localport:%d => %s:%d OK\n", ++cnt, i, host, port);
        }

        close(fd);
    }

    fprintf(stdout, "total: %d, failure: %d, loss: %.2f%%\n", cnt, fail, (cnt ? (double)fail / cnt * 100 : 0));

    return 0;
}


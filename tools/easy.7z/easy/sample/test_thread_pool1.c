#include <easy/easy_io.h>

easy_thread_pool_t *gtp = NULL;
easy_atomic_t      gscnt = 0;
easy_atomic_t      grcnt = 0;

int request_process(easy_baseth_t *th, easy_task_t *r)
{
    free(r);
    easy_atomic_inc(&grcnt);
    return EASY_ABORT;
}

void *send_request(void *args)
{
    while(1) {
        easy_atomic_inc(&gscnt);
        easy_request_t *r = (easy_request_t *) malloc(sizeof(easy_request_t));
        easy_list_init(&r->request_list_node);
        easy_thread_pool_addin(gtp, (easy_task_t *)r, easy_hash_key((long)r));

        while (gscnt - grcnt > 10000) usleep(1);
    }

    return (void *)NULL;
}

int main(int argc, char **argv)
{
    int scnt = 4;
    int rcnt = 4;
    int i;

    if (argc > 1) scnt = atoi(argv[1]);

    if (argc > 2) rcnt = atoi(argv[2]);

    // start
    ev_set_allocator(easy_pool_realloc);
    easy_pool_t *pool = easy_pool_create(0);
    pool->flags = 1;
    easy_io_t *eio = (easy_io_t *)easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->started = 1;
    eio->pool = pool;
    easy_list_init(&eio->thread_pool_list);
    gtp = easy_coroutine_pool_create(eio, rcnt, request_process, NULL);

    // start send
    int64_t start = easy_time_now();
    pthread_t tid[scnt];

    for(i = 0; i < scnt; i++) {
        pthread_create(&tid[i], NULL, send_request, NULL);
    }

    while(1) {
        sleep(1);
        int64_t end = easy_time_now();
        double speed = grcnt * 1000000.0 / (end - start);
        fprintf(stderr, "QPS: %.2f, pending: %ld.\r", speed, gscnt - grcnt);
    }

    for(i = 0; i < scnt; i++) {
        pthread_join(tid[i], NULL);
    }

    easy_baseth_pool_stop(gtp);
    easy_baseth_pool_wait(gtp);
    easy_baseth_pool_destroy(gtp);
    return 0;
}


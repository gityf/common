#ifndef APSARA_MUTEX_TABLE_H
#define APSARA_MUTEX_TABLE_H

#include <map>
#include <list>
#include <vector>

namespace apsara
{

    /**
     * This class is copied from RWLockTable. Two classes share lots of similar code. So any
     * bugfixs are likely to apply to both.
     */
    template<typename T>
    class MutexTable
    {
    public:
        MutexTable(uint32_t lockPoolCapacity)
            : mHashSet(lockPoolCapacity)
        {
            mCapacity = lockPoolCapacity;
        }

        ~MutexTable()
        {}

        size_t Size()
        {
            size_t size = 0;

            for (uint32_t i = 0; i < mCapacity; ++i)
                size += mHashSet[i].locks.size();

            return size;
        }

        void AcquireLock(const T &v)
        {
            uint64_t hashValue = (uint64_t)(v) % mCapacity;
            typename std::list<MutexInfo>::iterator i;
            HashEntry &entry = mHashSet[hashValue];
            {
                easy_spin_lock(&entry.mutex.wlock);
                i = entry.locks.begin();
                bool needCreate = true;

                for (; i != entry.locks.end(); ++i) {
                    if (i->value < v)
                        continue;
                    else if(v < i->value)
                        break;
                    else {
                        needCreate = false;
                        break;
                    }
                }

                if (needCreate)
                    i = entry.locks.insert(i, MutexInfo(v));

                (i->waiters)++;
                easy_spin_unlock(&entry.mutex.wlock);
            }
            easy_comutex_lock(&i->mutex);
        }

        void ReleaseLock(const T &v)
        {
            uint64_t hashValue = (uint64_t)(v) % mCapacity;
            typename std::list<MutexInfo>::iterator i;
            {
                HashEntry &entry = mHashSet[hashValue];
                easy_spin_lock(&entry.mutex.wlock);
                i = entry.locks.begin();
                bool hasFound = false;

                for (; i != entry.locks.end(); ++i) {
                    if (i->value < v)
                        continue;
                    else if(v < i->value)
                        break;
                    else {
                        hasFound = true;
                        break;
                    }
                }

                if (hasFound) {
                    easy_comutex_unlock(&i->mutex);

                    if ( --(i->waiters) == 0 ) {
                        entry.locks.erase(i);
                    }
                }

                easy_spin_unlock(&entry.mutex.wlock);

                if (!hasFound)
                    abort();
            }
        }

    private:
        struct MutexInfo {
            T             value;
            uint32_t      waiters;
            easy_comutex_t mutex;


            MutexInfo(const T &v)
                : value(v), waiters(0)
            {
                easy_comutex_init(&mutex);
            }

            MutexInfo(const MutexInfo &rwli)
            {
                this->value = rwli.value;
                this->waiters = rwli.waiters;
                easy_comutex_init(&mutex);
            }
            MutexInfo &operator=(const MutexInfo &rwli)
            {
                if (this != &rwli) {
                    this->value = rwli.value;
                    this->waiters = rwli.waiters;
                    easy_comutex_init(&mutex);
                }

                return *this;
            }
        };

        struct HashEntry {
            std::list<MutexInfo> locks;
            easy_comutex_t mutex;

            HashEntry()
            {
                easy_comutex_init(&mutex);
            }
            HashEntry(const HashEntry &he)
            {
                this->locks = he.locks;
                easy_comutex_init(&mutex);
            }
            HashEntry &operator=(const HashEntry &he)
            {
                if (this != &he) {
                    this->locks = he.locks;
                    easy_comutex_init(&mutex);
                }

                return *this;
            }

        };
        typedef std::vector<HashEntry> HashSet;

        // Non-copyable
        MutexTable(const MutexTable<T> &) {}
        void operator=(const MutexTable<T> &) {}

    private:
        size_t mCapacity;
        HashSet mHashSet;
    };


    /**
     * A auto-unlocker similar to ScopedLock.
     */
    template <typename T>
    class ScopedLockInTable
    {
    public:
        ScopedLockInTable(MutexTable<T> &lockTable, const T &value)
        {
            lockTable.AcquireLock(value);

            mLockTablePtr = &lockTable;
            mValue = value;
        }

        ~ScopedLockInTable()
        {
            mLockTablePtr->ReleaseLock(mValue);
        }

    private:
        // Non-copyable
        ScopedLockInTable(const ScopedLockInTable &) {}
        void operator=(const ScopedLockInTable &) {}

    private:
        MutexTable<T> *mLockTablePtr;
        T mValue;
    };

} // namespace apsara

#endif // APSARA_MUTEX_TABLE_H


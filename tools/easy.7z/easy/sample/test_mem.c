#include <easy/easy_io.h>

void test1(int cnt)
{
    int i, n;
    int xcnt = 10000;
    int lcnt = cnt / xcnt;
    char **ptr = (char **)malloc(xcnt * sizeof(char *));
    int64_t tt = 0;
    int64_t tt1 = easy_time_now();

    for(n = 0; n < lcnt ; n++) {
        int64_t t1 = easy_time_now();

        for(i = 0; i < xcnt; i++) {
            ptr[i] = malloc(128);
        }

        int64_t t2 = easy_time_now();
        tt += (t2 - t1);

        for(i = 0; i < xcnt; i++) {
            free(ptr[i]);
        }
    }

    int64_t tt2 = easy_time_now();

    easy_error_log("test1: cost time: %ld, free: %ld\n", tt, tt2 - tt1);
}

typedef struct test_mem_t {
    int64_t dcnt;
    char *ptr;
    int64_t align[6];
} test_mem_t;

void *test2(void *args)
{
    int i, xcnt = 10000;
    test_mem_t *t = (test_mem_t *) args;

    while(1) {
        easy_pool_t *pool = easy_pool_create(4096);

        for(i = 0; i < xcnt; i++) {
            t->ptr = easy_pool_alloc(pool, 32);
        }

        easy_pool_destroy(pool);
        t->dcnt += xcnt;
    }

    return (void *)NULL;
}

int main(int argc, char **argv)
{
    int i;
    int cnt = 1;

    if (argc > 1) cnt = atoi(argv[1]);

    pthread_t tid[cnt];
    test_mem_t args[cnt];
    memset(args, 0, sizeof(args));

    for(i = 0; i < cnt; i++) {
        pthread_create(&tid[i], NULL, test2, &args[i]);
    }

    // test2
    int64_t start = easy_time_now();

    while(1) {
        sleep(1);
        int64_t end = easy_time_now();
        int64_t acnt = 0;

        for(i = 0; i < cnt; i++) {
            acnt += args[i].dcnt;
        }

        fprintf(stdout, "QPS: %ld\r", acnt * 1000000 / (end - start));
        fflush(stdout);
    }

    return 0;
}


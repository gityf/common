#include <easy/easy_test.h>

/**
 * 测试 src/util
 */
RUN_TEST_MAIN


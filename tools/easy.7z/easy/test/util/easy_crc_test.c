#include <easy/easy_crc.h>
#include <easy/easy_test.h>

/**
 * 测试 easy_crc
 */
extern uint32_t easy_docrc32c_lookup(uint32_t crc, const uint8_t *data, uint64_t length);
TEST(easy_crc, test)
{
    {
        char *str = "adfasdfdfasdf";
        uint32_t a = easy_crc32c(0, (uint8_t *)str, strlen(str));
        EXPECT_EQ(a, 3056981916);

        uint32_t b = easy_docrc32c_lookup(0, (uint8_t *)str, strlen(str));
        EXPECT_EQ(a, b);
    }
    {
        char *str = "adfasdfdfasdf123";

        uint32_t b = easy_docrc32c_lookup(0, (uint8_t *)str, strlen(str));
        uint32_t a = easy_crc32c(0, (uint8_t *)str, strlen(str));
        EXPECT_EQ(a, b);
    }
}


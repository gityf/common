#include <easy/easy_hashx.h>
#include <easy/easy_buf.h>
#include <easy/easy_test.h>

/**
 * 测试 easy_hash
 */
typedef struct test_t {
    int                     id;
    easy_hashx_node_t       node;
} test_t;


TEST(easy_hashx, create)
{
    easy_hashx_t            *table;

    table = easy_hashx_create(100, 0);
    EXPECT_TRUE(table != NULL);
    EXPECT_EQ(table->size, 128);
    easy_hashx_destroy(table);
}

TEST(easy_hashx, add_resize_find_del)
{
    easy_hashx_t            *table;
    test_t                  *objects, *obj;
    int                     i, size;
    uint32_t                n;
    easy_hashx_node_t       *node, *next;

    table = easy_hashx_create(100, offsetof(test_t, node));

    EXPECT_TRUE(table != NULL);
    EXPECT_EQ(table->size, 128);

    // 1 add resize
    objects = (test_t *)malloc(sizeof(test_t) * 512);
    memset(objects, 0, sizeof(test_t) * 512);

    for (i = 0; i < 96; ++i) {
        easy_hashx_add(table, i, &objects[i].node);
    }

    EXPECT_EQ(table->size, 128);
    EXPECT_EQ(table->count, 96);
    easy_hashx_add(table, 96, &objects[96].node);
    EXPECT_EQ(table->size, 256);
    EXPECT_EQ(table->count, 97);

    for (i = 97; i < 512; ++i) {
        easy_hashx_add(table, i, &objects[i].node);
    }

    EXPECT_EQ(table->size, 1024);
    EXPECT_EQ(table->count, 512);

    // 2 find
    size = 0;

    for(i = 0; i < 512; ++i) {
        obj = (test_t *)easy_hashx_find(table, i);

        if (obj == &objects[i]) size++;
    }

    EXPECT_EQ(size, 512);

    // 3 not found
    size = 0;

    for(i = 0; i < 512; ++i) {
        obj = (test_t *)easy_hashx_find(table, i + 0x10000);

        if (!obj) size++;
    }

    EXPECT_EQ(size, 512);

    // 4 foreach
    size = 0;
    easy_hashx_for_each(n, node, table) {
        size++;
    }
    EXPECT_EQ(size, 512);

    // 5 del
    size = 0;

    for(i = 0; i < 500; i++) {
        obj = (test_t *)easy_hashx_del(table, i);

        if (obj == &objects[i]) size ++;

        if (obj) memset(obj, 0, sizeof(test_t));
    }

    obj = (test_t *)easy_hashx_del(table, 0);
    EXPECT_EQ(size, 500);
    EXPECT_EQ(table->count, 12);
    EXPECT_TRUE(obj == NULL);

    // 6.del_node
    for(i = 0; i < 500; i++) {
        easy_hashx_add(table, i, &objects[i].node);
    }

    size = 0;

    for(i = 0; i < 512; i++) {
        if (easy_hashx_del_node( &objects[i].node)) size ++;
    }

    EXPECT_EQ(size, 512);

    easy_hashx_del_node((easy_hashx_node_t *)&objects[0].node);

    // check
    size = 0;
    easy_hashx_for_each(n, node, table) {
        size ++;
    }
    EXPECT_EQ(size, 0);

    // safe for each
    size = 0;

    for(i = 0; i < 512; i++) {
        easy_hashx_add(table, i, &objects[i].node);
    }

    easy_hashx_for_each_safe(i , node, next, table) {
        next = node->next;
        easy_hashx_del_node(node);
        size++;
    }

    EXPECT_EQ(size, 512);
    easy_hashx_destroy(table);
    free(objects);
}

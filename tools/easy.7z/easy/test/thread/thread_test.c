#include <easy/easy_test.h>

RUN_TEST_MAIN


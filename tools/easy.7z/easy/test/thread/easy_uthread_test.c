#include <easy/easy_uthread.h>
#include <easy/easy_test.h>

typedef struct test_euc_args_t {
    easy_uthread_control_t *euc;
    easy_list_t            list;
    int                    cnt;
    int                    done;
} test_euc_args_t;

void test_easy_uthread_fn1(void *args, void *args2)
{
    test_euc_args_t *tea = (test_euc_args_t *) args;
    tea->cnt ++;
    easy_uthread_t *ut = easy_uthread_current();
    easy_list_add_tail(&ut->task_list_node, &tea->list);
    easy_uthread_switch();
    tea->done ++;
}

void test_easy_uthread_fn(void *args, void *args2)
{
    test_euc_args_t *tea = (test_euc_args_t *) args;
    tea->cnt ++;

    int i = 0;

    for(i = 0; i < 1100; i++) {
        easy_uthread_exec(tea->euc, test_easy_uthread_fn1, tea, NULL);
    }

    for(i = 0; i < 1142; i++) {
        easy_uthread_exec(tea->euc, test_easy_uthread_fn1, tea, NULL);

        if (i % 95 == 0) {
            easy_uthread_t *ut, *ut2;
            easy_list_for_each_entry_safe(ut, ut2, &tea->list, task_list_node) {
                easy_list_del(&ut->task_list_node);
                easy_uthread_ready(ut);
            }
            easy_list_init(&tea->list);
            easy_uthread_loop_yield(tea->euc);
        }
    }

    easy_uthread_print(0);
}

TEST(easy_uthread, easy_uthread_create)
{
    test_euc_args_t args;
    easy_uthread_control_t control;
    easy_uthread_init(&control);
    memset(&args, 0, sizeof(args));
    easy_list_init(&args.list);
    args.euc = &control;

    easy_uthread_exec(&control, test_easy_uthread_fn, &args, NULL);
    EXPECT_EQ(args.cnt, 2243);

    easy_uthread_destroy();
    easy_uthread_destroy();
}

#ifdef XXXX
static void *test_realloc (void *ptr, size_t size)
{
    return NULL;
}
TEST(easy_uthread, other)
{
    easy_uthread_control_t  control;
    easy_uthread_init(&control);

    easy_pool_set_allocator(test_realloc);
    easy_uthread_create(NULL, NULL, 10);
    easy_pool_set_allocator(easy_test_realloc);

    easy_uthread_destroy();

    EXPECT_TRUE(easy_uthread_current() == NULL);
    EXPECT_TRUE(easy_uthread_get_errcode() == 0);

}

#endif

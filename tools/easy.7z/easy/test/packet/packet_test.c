#include <easy/easy_test.h>

/**
 * gtest主程序
 */
RUN_TEST_MAIN


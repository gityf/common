#include <easy/easy_baseth_pool.h>
#include <easy/easy_io.h>
#include <easy/easy_test.h>
#include <easy/easy_simple_handler.h>
#include <easy/easy_socket.h>
#include <sys/wait.h>

easy_atomic_t cnt = 0;

void process_inc(struct ev_loop *loop, ev_timer *w, int revents)
{
    easy_atomic_inc(&cnt);
}

TEST(easy_timer, exec)
{
    easy_io_t               *eio;
    easy_baseth_t           *th1, *th2;
    ev_timer                timer[2];

    eio = easy_io_create(2);
    easy_io_start();
    th1 = (easy_baseth_t *) easy_thread_pool_index(eio->io_thread_pool, 0);
    EXPECT_TRUE(th1 != NULL);

    th2 = (easy_baseth_t *) easy_thread_pool_index(eio->io_thread_pool, 1);
    EXPECT_TRUE(th2 != NULL);

    ev_timer_init(&timer[0], process_inc, 0.5, 0.0);
    ev_timer_init(&timer[1], process_inc, 0.5, 0.0);
    easy_timer_start(th1, &timer[0]);
    easy_timer_start(th2, &timer[1]);

    sleep(1);
    EXPECT_EQ(cnt, 2);
    easy_io_stop();
    easy_io_wait();
    easy_io_destroy();
}

TEST(easy_timer, many)
{
    easy_io_t               *eio;
    easy_baseth_t           *th;
    ev_timer                timer[100];
    int                     i;

    eio = easy_io_create(2);
    easy_io_start();
    th = (easy_baseth_t *) easy_thread_pool_index(eio->io_thread_pool, 1);

    for (i = 0; i < 100; i++) {
        ev_timer_init(&timer[i], process_inc, 0.5, 0.0);
        easy_timer_start(th, &timer[i]);
    }

    easy_io_stop();
    easy_io_wait();
    easy_io_destroy();

}
///////////////////////////////////////////////////////////////////////////////////////////////////
static int test_register_server1_process(easy_request_t *r)
{
    easy_simple_packet_t    *packet, *request;

    request = (easy_simple_packet_t *)r->ipacket;
    packet = easy_simple_rnew(r, request->len);
    packet->len = request->len;
    packet->chid = request->chid;
    packet->data = &packet->buffer[0];
    memcpy(packet->data, request->data, request->len);
    r->opacket = packet;

    if (memcmp(packet->data, "STOP", 4) == 0) {
        easy_io_stop();
    }

    return EASY_OK;
}
void test_register_server1(const char *name)
{
    easy_addr_t addr;
    addr.family = AF_UNIX;
    addr.u.unix_path = name;

    int flags = 0;
    int fd = easy_socket_listen(0, &addr, &flags, 128);

    if (fd < 0) {
        EXPECT_TRUE(0);
        return;
    }

    easy_io_handler_pt      io_handler;
    easy_io_create(4);
    easy_log_level = (easy_log_level_t)0;
    memset(&io_handler, 0, sizeof(easy_io_handler_pt));
    io_handler.decode = easy_simple_decode;
    io_handler.encode = easy_simple_encode;
    io_handler.process = test_register_server1_process;
    io_handler.get_packet_id = easy_simple_packet_id;

    easy_io_start();
    easy_register_listen_fd(&easy_io_var, fd, &io_handler);
    easy_io_wait();
    easy_io_destroy();
}
static int test_register_client1_cnt = 0;
static int test_register_client1_cntd = 0;
static int test_register_client1_process(easy_request_t *r)
{

    if (r->ipacket) test_register_client1_cnt ++;

    easy_session_destroy((easy_session_t *)r->ms);

    if (++test_register_client1_cntd == 10) easy_io_stop();

    return EASY_OK;
}
int test_register_client1(const char *name)
{
    int                fd;
    easy_addr_t        paddr;
    struct sockaddr_un addr;
    easy_io_handler_pt io_handler;

    if ((fd = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
        EXPECT_TRUE(0);
        return EASY_ERROR;
    }

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    snprintf(addr.sun_path, UNIX_PATH_MAX, "%s", name);
    easy_socket_non_blocking(fd);
    easy_socket_colexec(fd);

    usleep(10000);

    if (connect(fd, (struct sockaddr *)&addr, SUN_LEN(&addr)) < 0) {
        easy_error_log("error: %s\n", strerror(errno));
        EXPECT_TRUE(0);
        return EASY_ERROR;
    }

    easy_log_level = (easy_log_level_t)0;
    easy_io_create(4);
    memset(&io_handler, 0, sizeof(easy_io_handler_pt));
    io_handler.decode = easy_simple_decode;
    io_handler.encode = easy_simple_encode;
    io_handler.process = test_register_client1_process;
    io_handler.get_packet_id = easy_simple_packet_id;

    easy_io_start();
    easy_register_client_fd(&easy_io_var, fd, &io_handler, &paddr);

    int i, chid = 1, total = 10;
    easy_session_t *s;
    easy_simple_packet_t    *packet;

    for(i = 0; i < total; i++) {
        if ((packet = easy_simple_new(&s, sizeof(int))) == NULL) {
            EXPECT_TRUE(0);
            break;
        }

        packet->data = &packet->buffer[0];
        packet->len = sizeof(int);
        packet->chid = ++chid;
        *((int *)packet->data) = packet->chid + 1;

        if (i + 1 == total) memcpy(packet->data, "STOP", 4);

        easy_session_set_request(s, packet, 3000, NULL);

        if (easy_io_dispatch(paddr, s) != EASY_OK) {
            easy_session_destroy(s);
        }
    }

    easy_io_wait();
    easy_io_destroy();
    EXPECT_EQ(test_register_client1_cnt, total);

    return EASY_OK;
}
TEST(easy_register, domain_socket)
{
    pid_t                   pid;
    int                     ret = 0;
    const char              *name = "/tmp/test_reg_fd.sock";


    // server
    if ((pid = fork()) == 0) {
        test_register_server1(name);
        exit(easy_test_retval);
    } else {
        if (test_register_client1(name) == EASY_ERROR) {
            kill(pid, SIGINT);
            usleep(1000);
        }
    }

    waitpid(pid, &ret, 0);
    EXPECT_EQ(WEXITSTATUS(ret), 0);
}
///////////////////////////////////////////////////////////////////////////////////////////////////
static int test_register_server2_process(easy_request_t *r)
{
    easy_simple_packet_t    *packet, *request;

    request = (easy_simple_packet_t *)r->ipacket;
    packet = easy_simple_rnew(r, request->len);
    packet->len = request->len;
    packet->chid = request->chid;
    packet->data = &packet->buffer[0];
    memcpy(packet->data, request->data, request->len);
    r->opacket = packet;

    if (memcmp(packet->data, "STOP", 4) == 0) {
        easy_io_stop();
    }

    return EASY_OK;
}
int test_register_server2_write(easy_connection_t *c, easy_list_t *l)
{
    int old = c->fd;
    c->fd = (long)c->handler->user_data;
    int ret = easy_socket_write(c, l);
    c->fd = old;
    return ret;
}
int test_register_server2_connect(easy_connection_t *c)
{
    c->write = test_register_server2_write;
    return EASY_OK;
}
void test_register_server2(int rfd, int wfd)
{
    easy_io_handler_pt      io_handler;
    easy_io_create(4);
    easy_log_level = (easy_log_level_t)5;
    memset(&io_handler, 0, sizeof(easy_io_handler_pt));
    io_handler.decode = easy_simple_decode;
    io_handler.encode = easy_simple_encode;
    io_handler.on_connect = test_register_server2_connect;
    io_handler.process = test_register_server2_process;
    io_handler.get_packet_id = easy_simple_packet_id;
    io_handler.user_data = (void *)(long)wfd;

    easy_io_start();
    easy_register_server_fd(&easy_io_var, rfd, &io_handler);
    easy_io_wait();
    easy_io_destroy();
}
static int test_register_client2_cnt = 0;
static int test_register_client2_cntd = 0;
static int test_register_client2_process(easy_request_t *r)
{

    if (r->ipacket) test_register_client2_cnt ++;

    easy_session_destroy((easy_session_t *)r->ms);

    if (++test_register_client2_cntd == 10) easy_io_stop();

    return EASY_OK;
}
int test_register_client2(int rfd, int wfd)
{
    easy_addr_t        paddr;
    easy_io_handler_pt io_handler;

    easy_log_level = (easy_log_level_t)5;
    easy_io_create(4);
    memset(&io_handler, 0, sizeof(easy_io_handler_pt));
    io_handler.decode = easy_simple_decode;
    io_handler.encode = easy_simple_encode;
    io_handler.on_connect = test_register_server2_connect;
    io_handler.process = test_register_client2_process;
    io_handler.get_packet_id = easy_simple_packet_id;
    io_handler.user_data = (void *)(long)wfd;

    easy_io_start();
    easy_register_client_fd(&easy_io_var, rfd, &io_handler, &paddr);

    int i, chid = 1, total = 10;
    easy_session_t *s;
    easy_simple_packet_t    *packet;

    for(i = 0; i < total; i++) {
        if ((packet = easy_simple_new(&s, sizeof(int))) == NULL) {
            EXPECT_TRUE(0);
            break;
        }

        packet->data = &packet->buffer[0];
        packet->len = sizeof(int);
        packet->chid = ++chid;
        *((int *)packet->data) = packet->chid + 1;

        if (i + 1 == total) memcpy(packet->data, "STOP", 4);

        easy_session_set_request(s, packet, 1000, NULL);

        if (easy_io_dispatch(paddr, s) != EASY_OK) {
            easy_session_destroy(s);
        }
    }

    easy_io_wait();
    easy_io_destroy();
    EXPECT_EQ(test_register_client2_cnt, total);

    return EASY_OK;
}
TEST(easy_register, pipe)
{
    int                     pfd1[2];
    int                     pfd2[2];
    pid_t                   pid;
    int                     ret = 0;

    if (pipe(pfd1) == -1) return;

    if (pipe(pfd2) == -1) return;

    // server
    if ((pid = fork()) == 0) {
        close(pfd1[1]);
        close(pfd2[0]);
        test_register_server2(pfd1[0], pfd2[1]);
        exit(easy_test_retval);
    } else {
        close(pfd1[0]);
        close(pfd2[1]);

        if (test_register_client2(pfd2[0], pfd1[1]) == EASY_ERROR) {
            kill(pid, SIGINT);
            usleep(1000);
        }
    }

    waitpid(pid, &ret, 0);
    EXPECT_EQ(WEXITSTATUS(ret), 0);
}


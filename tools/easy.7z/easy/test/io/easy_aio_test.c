#include <easy/easy_aio.h>
#include <easy/easy_io.h>
#include <easy/easy_test.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <unistd.h>
/* no one use it */
//#include <linux/falloc.h>

/**
 * 测试easy_aio
 */
///////////////////////////////////////////////////////////////////////////////////////////////////
typedef struct {
    int             fd;
    char            *buffer;
    easy_atomic_t   send_cnt;
    easy_atomic_t   done_cnt;
    easy_atomic_t   fail_cnt;
    easy_atomic_t   read_send;
    easy_atomic_t   read_done;
    easy_atomic_t   read_fail;
} easy_aio_test_t;

#define TEST_FILE_SIZE (500 * 1024 *1024)

void easy_aio1_write_callback(easy_aio_event_t *ev, void *args)
{
    easy_aio_test_t *at = (easy_aio_test_t *) args;

    if (ev->res == 1024) {
        easy_atomic_inc(&at->done_cnt);
    } else {
        easy_error_log("write ret: %ld\n", ev->res);
        easy_atomic_inc(&at->fail_cnt);
    }
}

int easy_aio1_write_process(easy_baseth_t *th, easy_task_t *r)
{
    easy_aio_test_t *at = (easy_aio_test_t *) r->user_data;
    uint64_t offset = rand();
    int type = offset * 10243 % 2;
    offset *= 10243;
    offset %= TEST_FILE_SIZE;
    offset = easy_align(offset, 512);
    struct iovec *iov = (struct iovec *)(at->buffer + 1024);
    iov[0].iov_base = at->buffer;
    iov[1].iov_base = at->buffer + 512;
    iov[0].iov_len = 512;
    iov[1].iov_len = 512;

    int64_t t1 = easy_time_now();
    int ret;

    if (type == 0) {
        ret = easy_aio_pwritev(at->fd, iov, 2, offset, easy_aio1_write_callback, at);
    } else {
        ret = easy_aio_pwrite(at->fd, at->buffer, 1024, offset, easy_aio1_write_callback, at);
    }

    int64_t t2 = easy_time_now();

    if (ret == EASY_OK && (t2 - t1) <= 10000) {
        easy_atomic_inc(&at->send_cnt);
    } else {
        if (ret == EASY_OK) {
            easy_error_log("pwrite cost time: %ld us, offset: %ld\n", (t2 - t1), offset);
            easy_atomic_inc(&at->send_cnt);
        } else {
            easy_atomic_inc(&at->fail_cnt);
        }
    }

    free(r);
    return EASY_ABORT;
}

void easy_aio1_read_callback(easy_aio_event_t *ev, void *args)
{
    easy_task_t *r = (easy_task_t *) args;
    easy_aio_test_t *at = (easy_aio_test_t *) r->user_data;

    if (ev->res == 1024 && memcmp(r->timeout_watcher.data, at->buffer, 1024) == 0) {
        easy_atomic_inc(&at->read_done);
    } else {
        easy_error_log("read ret: %ld\n", ev->res);
        easy_atomic_inc(&at->read_fail);
    }

    free(r);
}

int easy_aio1_read_process(easy_baseth_t *th, easy_task_t *r)
{
    easy_aio_test_t *at = (easy_aio_test_t *) r->user_data;
    uint64_t offset = rand();
    int type = offset * 10243 % 2;
    offset *= 10243;
    offset %= 1024 * 1023;
    offset = easy_align(offset, 512);
    struct iovec *iov = (struct iovec *)(r->timeout_watcher.data + 1024);
    iov[0].iov_base = r->timeout_watcher.data;
    iov[1].iov_base = r->timeout_watcher.data + 512;
    iov[0].iov_len = 512;
    iov[1].iov_len = 512;

    if (type == 0 && easy_aio_preadv(at->fd, iov, 2, offset, easy_aio1_read_callback, r) == EASY_OK) {
        easy_atomic_inc(&at->read_send);
    } else if (easy_aio_pread(at->fd, r->timeout_watcher.data, 1024, offset, easy_aio1_read_callback, r) == EASY_OK) {
        easy_atomic_inc(&at->read_send);
    } else {
        easy_atomic_inc(&at->read_fail);
        free(r);
    }

    return EASY_ABORT;
}

TEST(easy_aio, test_1)
{
    int                 i;
    easy_aio_test_t     at;
    easy_pool_t         *pool;
    easy_io_t           *eio;

    pool = easy_pool_create(0);
    eio = easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->pool = pool;
    eio->started = 1;
    easy_list_init(&eio->thread_pool_list);

    easy_thread_pool_t *tp = easy_coroutine_pool_create(eio, 4, easy_aio1_write_process, NULL);
    easy_aio_init(tp, 5000);
    easy_baseth_pool_start(tp);
    // start
    srand(time(NULL));
    memset(&at, 0, sizeof(at));
    at.fd = open("easy_aio.tmp", O_RDWR | O_CREAT | O_TRUNC | O_DIRECT, 0600);
    //at.fd = open("easy_aio.tmp", O_RDWR | O_CREAT | O_TRUNC, 0600);
    int error = 1; //syscall(SYS_fallocate, at.fd, FALLOC_FL_KEEP_SIZE, 0, TEST_FILE_SIZE);

    if (error) {
        int l = 1024 * 1024;
        char *buffer = (char *)malloc(l * 2);
        memset(buffer, 0, l * 2);
        char *p = (char *)easy_align_ptr(buffer, 512);

        for(i = 0; i < TEST_FILE_SIZE / l; i++) {
            if (pwrite(at.fd, p, l, i * l) < 0) {
                easy_error_log("fill failure: %d\n", errno);
            }
        }

        free(buffer);
        fsync(at.fd);
    }

    unlink("easy_aio.tmp");
    at.buffer = (char *)easy_pool_alloc(pool, 2048);
    memset(at.buffer, 'R', 2048);
    at.buffer = (char *)easy_align_ptr(at.buffer, 512);
    int cnt = 10000;

    for(i = 0; i < cnt; i++) {
        easy_task_t *r = (easy_task_t *)calloc(1, sizeof(easy_task_t));
        r->istask = 1;
        r->user_data = &at;
        easy_thread_pool_addin(tp, r, i);

        while(at.done_cnt + at.fail_cnt + 1000 < i) usleep(1000);
    }

    while(at.done_cnt + at.fail_cnt != cnt) usleep(10000);

    EXPECT_TRUE(at.done_cnt == cnt);

    for(i = 0; i < 1024; i++) {
        pwrite(at.fd, at.buffer, 1024, i * 1024);
    }

    for(i = 0; i < cnt; i++) {
        easy_task_t *r = (easy_task_t *)calloc(1, sizeof(easy_task_t) + 2048);
        char *p = (char *)(r + 1);
        r->timeout_watcher.data = easy_align_ptr(p, 512);
        r->task_process = easy_aio1_read_process;
        r->istask = 1;
        r->user_data = &at;
        easy_thread_pool_addin(tp, r, i);

        while(at.read_done + at.read_fail + 1000 < i) usleep(1000);
    }

    while(at.read_done + at.read_fail != cnt) usleep(10000);

    EXPECT_TRUE(at.read_done == cnt);

    close(at.fd);
    easy_baseth_pool_stop(tp);
    easy_baseth_pool_wait(tp);
    easy_baseth_pool_destroy(tp);

    easy_pool_destroy(pool);
}
///////////////////////////////////////////////////////////////////////////////////////////////////

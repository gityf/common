#include <easy/easy_test.h>

/**
 * 测试 src/io
 */
RUN_TEST_MAIN

#include <easy/easy_io.h>
#include <easy/easy_test.h>
#include <easy/easy_message.h>
#include <unistd.h>

#define THREAD_POOL_CREATE(on_process)                          \
    easy_pool_t             *pool;                              \
    easy_io_t               *eio;                               \
    easy_thread_pool_t      *tp;                                \
    easy_message_t          *m;                                 \
    pool = easy_pool_create(0);                                 \
    eio = easy_pool_calloc(pool, sizeof(easy_io_t));            \
    eio->pool = pool;                                           \
    eio->started = 1;                                           \
    easy_list_init(&eio->thread_pool_list);                     \
    m = fake_message(pool);                                     \
    tp = easy_coroutine_pool_create(eio, 5, NULL, NULL);        \
    easy_baseth_set_process(tp, on_process, NULL);              \
    easy_baseth_pool_start(tp);

#define THREAD_POOL_DESTROY()                                   \
    easy_baseth_pool_destroy(tp);                               \
    pool->ref = 0;                                              \
    easy_pool_destroy(pool);                                    \
    m->pool->ref = 0;                                           \
    easy_pool_destroy(m->pool)

#define PROCESS_START                                           \
    easy_io_t               *eio = th->eio;                     \
    easy_atomic_inc(&testcoro_recv_cnt);

#define PROCESS_END                                             \
    easy_atomic_inc(&testcoro_done_cnt);                        \
    if (testcoro_done_cnt == testcoro_task_cnt) {               \
        easy_baseth_pool_stop(eio->thread_pool);                \
    }

#define GLOBAL_INIT(a)                                          \
    testcoro_task_cnt = a;                                      \
    testcoro_recv_cnt = 0;                                      \
    testcoro_done_cnt = 0;                                      \
    testcoro_cnt = 0;                                           \
    easy_comutex_init(&testcoro_lock);

easy_message_t *fake_message(easy_pool_t *pool);
easy_request_t *fake_request(easy_message_t *m);

typedef struct test_lock_t {
    int                 wcnt;
    int                 type;
    easy_comutex_t      *lock;
    struct test_lock_t  *flock;
} test_lock_t;

//global var
easy_atomic_t               testcoro_recv_cnt;
easy_atomic_t               testcoro_done_cnt;
easy_comutex_t              testcoro_lock;
int                         testcoro_task_cnt;
int                         testcoro_cnt;

int test_call(easy_baseth_t *th, void *args)
{
    easy_atomic_inc(&testcoro_done_cnt);
    return EASY_OK;
}
int test_process(easy_baseth_t *th, easy_task_t *r)
{
    PROCESS_START
    easy_comutex_lock(&testcoro_lock);
    {
        easy_comutex_lock(&testcoro_lock);
        int org = testcoro_cnt;
        usleep(100);
        testcoro_cnt = org + 1;
        easy_comutex_unlock(&testcoro_lock);
    }
    easy_comutex_unlock(&testcoro_lock);
    PROCESS_END;
    return EASY_OK;
}

TEST(easy_coroutine, create)
{
    easy_pool_t             *pool;
    easy_io_t               *eio;
    pool = easy_pool_create(0);
    eio = easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->pool = pool;
    eio->started = 1;
    easy_list_init(&eio->thread_pool_list);
    {
        easy_thread_pool_t      *tp;
        testcoro_done_cnt = 0;
        tp = easy_coroutine_pool_create(eio, 5, test_process, NULL);
        easy_baseth_register_once(tp, test_call, NULL, 0);
        easy_baseth_register_once(tp, test_call, NULL, 1);

        easy_baseth_pool_start(tp);
        easy_baseth_pool_stop(tp);
        easy_baseth_pool_wait(tp);
        EXPECT_TRUE(testcoro_done_cnt == 2 * 5);
        testcoro_done_cnt = 0;
        easy_baseth_pool_destroy(tp);
    }
    easy_pool_destroy(pool);
}

TEST(easy_coroutine, create2)
{
    easy_pool_t             *pool;
    easy_io_t               *eio;
    pool = easy_pool_create(0);
    eio = easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->pool = pool;
    eio->started = 1;
    easy_list_init(&eio->thread_pool_list);
    {
        easy_thread_pool_t      *tp;
        testcoro_done_cnt = 0;
        tp = easy_coroutine_pool_create(eio, 5, test_process, NULL);
        easy_baseth_register_once(tp, test_call, NULL, 0);
        easy_baseth_register_once(tp, test_call, NULL, 1);
        easy_baseth_pool_start(tp);
        easy_baseth_pool_stop(tp);
        easy_baseth_pool_wait(tp);
        EXPECT_TRUE(testcoro_done_cnt == 2 * 5);
        testcoro_done_cnt = 0;
        easy_baseth_pool_destroy(tp);
    }
    easy_pool_destroy(pool);
}

TEST(easy_coroutine, create3)
{
    easy_pool_t             *pool;
    easy_io_t               *eio;
    pool = easy_pool_create(0);
    eio = easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->pool = pool;
    eio->started = 1;
    easy_list_init(&eio->thread_pool_list);
    {
        easy_thread_pool_t      *tp;
        testcoro_done_cnt = 0;
        tp = easy_coroutine_pool_create(eio, 5, test_process, NULL);
        easy_baseth_register_once(tp, test_call, NULL, 0);
        easy_baseth_register_once(tp, test_call, NULL, 1);
        easy_baseth_pool_start(tp);
        easy_baseth_pool_stop(tp);
        easy_baseth_pool_wait(tp);
        EXPECT_TRUE(testcoro_done_cnt == 2 * 5);
        testcoro_done_cnt = 0;
        easy_baseth_pool_destroy(tp);
    }
    easy_pool_destroy(pool);
}

TEST(easy_coroutine, create4)
{
    easy_pool_t             *pool;
    easy_io_t               *eio;
    pool = easy_pool_create(0);
    eio = easy_pool_calloc(pool, sizeof(easy_io_t));
    eio->pool = pool;
    eio->started = 1;
    easy_list_init(&eio->thread_pool_list);
    {
        easy_thread_pool_t      *tp;
        testcoro_done_cnt = 0;
        tp = easy_coroutine_pool_create(eio, 5, test_process, NULL);
        easy_baseth_register_once(tp, test_call, NULL, 0);
        easy_baseth_register_once(tp, test_call, NULL, 1);
        easy_baseth_pool_start(tp);
        easy_baseth_pool_stop(tp);
        easy_baseth_pool_wait(tp);
        EXPECT_TRUE(testcoro_done_cnt == 2 * 5);
        testcoro_done_cnt = 0;
        easy_baseth_pool_destroy(tp);
    }
    easy_pool_destroy(pool);
}

TEST(easy_coroutine, easy_comutex_lock)
{
    THREAD_POOL_CREATE(test_process);
    GLOBAL_INIT(100);
    int                     i;
    easy_request_t          *r;

    for (i = 0; i < testcoro_task_cnt; i++) {
        r = fake_request(m);
        easy_thread_pool_push(tp, r, i);
    }

    easy_baseth_pool_wait(tp);
    EXPECT_TRUE(testcoro_recv_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_done_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_cnt == testcoro_done_cnt);

    THREAD_POOL_DESTROY();
}

//用于usleep 和 later
int time_process(easy_baseth_t *th, easy_task_t *r)
{
    PROCESS_START
    int *flag = (int *)r->user_data;

    if (*flag == 0) {
        // n+1
        easy_comutex_lock(&testcoro_lock);
        testcoro_cnt ++;
        easy_comutex_unlock(&testcoro_lock);
    } else {
        // n*2
        if (*flag == 1) {
            while (testcoro_done_cnt < (testcoro_task_cnt / 2)) {
                easy_coroutine_usleep(1000);
            }
        }

        easy_comutex_lock(&testcoro_lock);
        testcoro_cnt *= 2;
        easy_comutex_unlock(&testcoro_lock);
    }

    PROCESS_END
    return EASY_OK;
}

TEST(easy_coroutine, easy_coroutine_usleep)
{
    THREAD_POOL_CREATE(time_process);
    int                     i;
    easy_request_t          *r;
    GLOBAL_INIT(20);
    int flags[20];

    //10个加1， 10个乘以2
    for (i = 0; i < testcoro_task_cnt; i++) {
        flags[i] = i & 1;
        r = fake_request(m);
        r->user_data = &flags[i];
        r->iscoro = 1;
        r->task_process = easy_coroutine_process;
        easy_thread_pool_push(tp, r, i);
    }

    easy_baseth_pool_wait(tp);
    EXPECT_TRUE(testcoro_recv_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_done_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_cnt == 10 * 1024);

    THREAD_POOL_DESTROY();
}

int wakeup_process(easy_baseth_t *th, easy_task_t *r)
{
    PROCESS_START
    test_lock_t *test_lock = (test_lock_t *)r->user_data;
    test_lock_t *flock = test_lock->flock;
    easy_comutex_cond_lock(flock->lock);
    flock->wcnt ++;

    if (flock->type == 1) {
        if (flock->wcnt == 2) {
            easy_comutex_cond_signal(flock->lock);
        } else {
            easy_comutex_cond_wait(flock->lock);
        }
    } else if (flock->type == 2) {
        if (flock->wcnt == 3) {
            easy_comutex_cond_broadcast(flock->lock);
        } else {
            easy_comutex_cond_wait(flock->lock);
        }
    } else if (flock->type == 3) {
        if (flock->wcnt == 2) {
            easy_comutex_cond_signal(flock->lock);
        } else {
            uint64_t start = easy_time_now();
            int ret = easy_comutex_cond_timedwait(flock->lock, 10000);
            uint64_t end = easy_time_now();

            if (ret) {
                EXPECT_TRUE(end - start > 10000);
                EXPECT_TRUE(end - start < 20000);
            } else {
                EXPECT_TRUE(end - start < 10000);
            }
        }
    }

    easy_comutex_cond_unlock(flock->lock);
    PROCESS_END
    return EASY_OK;
}

TEST(easy_coroutine, easy_comutex_signal)
{
    THREAD_POOL_CREATE(wakeup_process);
    GLOBAL_INIT(20);
    int                 i;
    easy_request_t      *r;
    test_lock_t         *test_lock;
    test_lock_t         *flock = NULL;
    easy_comutex_t      *lock = NULL;

    for (i = 0; i < testcoro_task_cnt; i++) {
        r = fake_request(m);
        test_lock = (test_lock_t *)easy_pool_calloc(pool, sizeof(test_lock_t));

        if ((i & 1) == 0) {
            lock = (easy_comutex_t *) easy_pool_calloc(pool, sizeof(easy_comutex_t));
            easy_comutex_init(lock);
            flock = test_lock;
            flock->type = 1;
        }

        test_lock->flock = flock;
        test_lock->lock = lock;
        r->user_data = test_lock;
        easy_thread_pool_push(tp, r, i);
    }

    easy_baseth_pool_wait(tp);
    EXPECT_TRUE(testcoro_recv_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_done_cnt == testcoro_task_cnt);
    THREAD_POOL_DESTROY();
}

TEST(easy_coroutine, easy_comutex_broadcast)
{
    THREAD_POOL_CREATE(wakeup_process);
    GLOBAL_INIT(30);
    int                 i;
    easy_request_t      *r;
    test_lock_t         *test_lock;
    test_lock_t         *flock = NULL;
    easy_comutex_t      *lock = NULL;

    for (i = 0; i < testcoro_task_cnt; i++) {
        r = fake_request(m);
        test_lock = (test_lock_t *)easy_pool_calloc(pool, sizeof(test_lock_t));

        if (i % 3 == 0) {
            lock = (easy_comutex_t *) easy_pool_calloc(pool, sizeof(easy_comutex_t));
            easy_comutex_init(lock);
            flock = test_lock;
            flock->type = 2;
        }

        test_lock->flock = flock;
        test_lock->lock = lock;
        r->user_data = test_lock;
        r->iscoro = 1;
        r->task_process = easy_coroutine_process;
        easy_thread_pool_push(tp, r, i);
    }

    easy_baseth_pool_wait(tp);
    EXPECT_TRUE(testcoro_recv_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_done_cnt == testcoro_task_cnt);
    THREAD_POOL_DESTROY();
}

TEST(easy_coroutine, easy_uthread_timer)
{
    THREAD_POOL_CREATE(time_process);
    GLOBAL_INIT(20);
    int                 i;
    easy_request_t      *r;

    int flags[20];

    for (i = 0; i < testcoro_task_cnt; i++) {
        r = fake_request(m);

        if (i & 1) {
            flags[i] = 2;
            r->istimer = 1;
            r->task_process = easy_coroutine_process;
            ev_timer_set(&r->timeout_watcher, 0.05, 0.);
        } else {
            flags[i] = 0;
        }

        r->user_data = &flags[i];
        easy_thread_pool_push(tp, r, i);
    }

    easy_baseth_pool_wait(tp);
    EXPECT_TRUE(testcoro_recv_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_done_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_cnt == 10 * 1024);
    THREAD_POOL_DESTROY();
}

easy_message_t *fake_message(easy_pool_t *pool)
{
    easy_connection_t *c;
    easy_message_t  *m;
    c = (easy_connection_t *) easy_pool_calloc(pool, sizeof(easy_connection_t));
    c->pool = pool;
    easy_list_init(&c->message_list);
    easy_list_init(&c->server_requests);
    easy_list_init(&c->conn_list_node);
    easy_list_init(&c->output);
    m = easy_message_create(c);
    return m;
}

easy_request_t *fake_request(easy_message_t *m)
{
    easy_request_t *r;
    r = (easy_request_t *) easy_pool_calloc(m->pool, sizeof(easy_request_t));
    r->ms = (easy_message_session_t *) m;
    r->istask = 1;
    easy_list_add_tail(&r->request_list_node, &m->request_list);
    easy_list_add_tail(&r->all_node, &m->all_list);
    return r;
}

TEST(easy_coroutine, easy_comutex_timedwait)
{
    THREAD_POOL_CREATE(wakeup_process);
    GLOBAL_INIT(20);
    int                 i;
    easy_request_t      *r;
    test_lock_t         *test_lock;
    test_lock_t         *flock = NULL;
    easy_comutex_t      *lock = NULL;

    for (i = 0; i < testcoro_task_cnt; i++) {
        r = fake_request(m);
        test_lock = (test_lock_t *)easy_pool_calloc(pool, sizeof(test_lock_t));

        if ((i & 1) == 0) {
            lock = (easy_comutex_t *) easy_pool_calloc(pool, sizeof(easy_comutex_t));
            easy_comutex_init(lock);
            flock = test_lock;
            flock->type = 3;
        } else {
            usleep(10 + (i / 2 % 2) * 100000);
        }

        test_lock->flock = flock;
        test_lock->lock = lock;
        r->user_data = test_lock;
        r->iscoro = 1;
        r->task_process = easy_coroutine_process;
        easy_thread_pool_push(tp, r, i);
    }

    easy_baseth_pool_wait(tp);
    EXPECT_TRUE(testcoro_recv_cnt == testcoro_task_cnt);
    EXPECT_TRUE(testcoro_done_cnt == testcoro_task_cnt);
    THREAD_POOL_DESTROY();
}


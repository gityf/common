#ifndef EASY_IO_STRUCT_H_
#define EASY_IO_STRUCT_H_

#include <easy/easy_define.h>
#ifdef HAVE_LIBSSL
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/conf.h>
#include <openssl/engine.h>
#include <openssl/evp.h>
#endif

/**
 * IO结构定义
 */

EASY_CPP_START

#define EV_STANDALONE    1
#define EV_USE_MONOTONIC 0
#include <easy/ev.h>
#include <easy/easy_pool.h>
#include <easy/easy_buf.h>
#include <easy/easy_list.h>
#include <easy/easy_atomic.h>
#include <easy/easy_hash.h>
#include <easy/easy_uthread.h>
#include <easy/easy_inet.h>
#include <easy/easy_array.h>
#include <easy/easy_time.h>

#ifdef EASY_DEBUG_DOING
extern easy_atomic_t easy_debug_uuid;
#endif
///// define
#define EASY_MAX_THREAD_CNT         64
#define EASY_DELAY_THREAD_CNT       (-EASY_MAX_THREAD_CNT)
#define EASY_IOTH_DOING_REQ_CNT     8192
#define EASY_CONN_DOING_REQ_CNT     1024
#define EASY_WARN_LOG_INTERVAL      100
#define EASY_DEFAULT_CLICNT         1024
#define EASY_MSS                    1460

#define EASY_EVENT_READ             1
#define EASY_EVENT_WRITE            2
#define EASY_EVENT_TIMEOUT          4

#define EASY_TYPE_SERVER            0
#define EASY_TYPE_CLIENT            1

#define EASY_CONN_OK                0
#define EASY_CONN_CONNECTING        1
#define EASY_CONN_AUTO_CONN         2
#define EASY_CONN_CLOSE             3

#define EASY_CLIENT_DEFAULT_TIMEOUT 4000
#define EASY_IO_BUFFER_SIZE         8192
#define EASY_FIRST_MSGLEN           (EASY_IO_BUFFER_SIZE-1024)
#define EASY_MESG_READ_AGAIN        1
#define EASY_MESG_WRITE_AGAIN       2
#define EASY_MESG_DESTROY           3
#define EASY_REQUEST_DONE           1

#define EASY_IOV_MAX                128
#define EASY_IOV_SIZE               65536

#define EASY_FILE_READ              1
#define EASY_FILE_WRITE             2
#define EASY_FILE_SENDFILE          3
#define EASY_FILE_WILLNEED          4

// summary
#define EASY_SUMMARY_CNT            64
#define EASY_SUMMARY_LENGTH_BIT     10
#define EASY_SUMMARY_LENGTH         (1<<EASY_SUMMARY_LENGTH_BIT)
#define EASY_SUMMARY_LENGTH_MASK    (EASY_SUMMARY_LENGTH - 1)

#define EASY_DISCONNECT_ADDR        0x02
#define EASY_CONNECT_ADDR           0x03
#define EASY_CONNECT_SEND           0x05
#define EASY_OTHER_EVENT            0xf0
#define EASY_ADD_LISTEN             0x10

#define EASY_CONNECT_AUTOCONN       0x01
#define EASY_CONNECT_SSL            0x02

#define EASY_SESSION_ERROR          (-1)
#define EASY_SESSION_NOT_MEMORY     (-2)
#define EASY_SESSION_CONN_FAIL      (-3)
#define EASY_SESSION_TIMEOUT        (-4)
#define EASY_SESSION_DISCONN        (-5)
#define EASY_SESSION_DISCONNED      (-6)
#define EASY_SESSION_DECODE_FAIL    (-7)
#define EASY_SESSION_WRITE_FAIL     (-8)
#define EASY_SESSION_CONN_TIMEOUT   (-9)
#define EASY_SESSION_NOT_CONN       (-10)

#define EASY_TASK_TYPE_REQUEST      0
#define EASY_TASK_TYPE_UTHREAD      1
#define EASY_TASK_TYPE_MESSAGE      2
#define EASY_TASK_TYPE_SESSION      3
#define EASY_TASK_TYPE_CONN         4
#define EASY_TASK_TYPE_TIMER        5

#define EASY_TYPE_MESSAGE EASY_TASK_TYPE_MESSAGE
#define EASY_TYPE_SESSION EASY_TASK_TYPE_SESSION

#define EASY_REDISPATCH             0
#define EASY_NO_REDISPATCH          1
#define EASY_FIRST_DISPATCH         2

///// typedef
typedef struct easy_io_thread_t easy_io_thread_t;
typedef struct easy_message_t easy_message_t;
typedef struct easy_request_t easy_request_t;
typedef struct easy_task_t easy_task_t;
typedef struct easy_connection_t easy_connection_t;
typedef struct easy_message_session_t easy_message_session_t;
typedef struct easy_session_t easy_session_t;
typedef struct easy_listen_t easy_listen_t;
typedef struct easy_client_t easy_client_t;
typedef struct easy_io_t easy_io_t;
typedef struct easy_io_handler_pt easy_io_handler_pt;
typedef struct easy_io_stat_t easy_io_stat_t;
typedef struct easy_baseth_t easy_baseth_t;
typedef struct easy_thread_pool_t easy_thread_pool_t;
typedef struct easy_cond_t easy_cond_t;
typedef struct easy_client_wait_t easy_client_wait_t;
typedef struct easy_file_task_t easy_file_task_t;
#ifdef SUMMARY_ENABLE
typedef struct easy_summary_node_t easy_summary_node_t;
typedef struct easy_summary_t easy_summary_t;
#endif
typedef struct easy_coroutine_thread_t easy_coroutine_thread_t;
typedef struct easy_comutex_t easy_comutex_t;
typedef struct easy_thread_once_t easy_thread_once_t;
typedef struct easy_aio_t easy_aio_t;
typedef unsigned long easy_aio_ctx_t;

typedef struct easy_timeout_queue_t easy_timeout_queue_t;

#ifdef HAVE_LIBSSL
typedef struct easy_client_ssl_t easy_client_ssl_t;
typedef struct easy_ssl_t easy_ssl_t;
typedef struct easy_ssl_ctx_t easy_ssl_ctx_t;
typedef struct easy_ssl_connection_t easy_ssl_connection_t;
typedef void (easy_ssl_schandler_pt)(easy_connection_t *c);
#endif

typedef int (easy_io_process_pt)(easy_request_t *r);
typedef int (easy_io_cleanup_pt)(easy_request_t *r, void *apacket);
typedef int (easy_task_process_pt)(easy_baseth_t *th, easy_task_t *r);
typedef void (easy_io_stat_process_pt)(easy_io_stat_t *iostat);
typedef void *(easy_baseth_on_start_pt)(void *args);
typedef void (easy_baseth_on_process_pt)(easy_baseth_t *th);
typedef void (easy_baseth_on_wakeup_pt)(struct ev_loop *loop, ev_async *w, int revents);
typedef int (easy_read_pt)(easy_connection_t *c, char *buf, int size, int *pending);
typedef int (easy_write_pt)(easy_connection_t *c, easy_list_t *l);
typedef void *(easy_decode_pt)(easy_message_t *m);
typedef int (easy_encode_pt)(easy_request_t *r, void *packet);
typedef int (easy_thread_once_pt)(easy_baseth_t *th, void *args);
typedef void (easy_timer_exec_pt)(struct ev_loop *loop, ev_timer *timer);

struct easy_io_handler_pt {
    easy_decode_pt          *decode;
    easy_encode_pt          *encode;
    easy_io_process_pt      *process;
    int                     (*batch_process)(easy_message_t *m);
    easy_io_cleanup_pt      *cleanup;
    uint64_t                (*get_packet_id)(easy_connection_t *c, void *packet);
    int                     (*on_connect) (easy_connection_t *c);
    int                     (*on_disconnect) (easy_connection_t *c);
    int                     (*new_packet) (easy_connection_t *c);
    int                     (*on_idle) (easy_connection_t *c);
    int                     (*set_data) (easy_request_t *r, const char *data, int len);
    void                    (*sending_data) (easy_connection_t *c);
    int                     (*send_data_done) (easy_connection_t *c);
    void                    *user_data, *user_data2;
    int8_t                  is_uthread, is_ssl, is_udp;
};

#define EASY_TASK_NODE_HEADER(name)                 \
    easy_list_t                     name;           \
    easy_task_process_pt*           task_process;   \
    void*                           task_args;      \
    int8_t                          task_type;

// EASY_BASETH_DEFINE
#define EASY_BASETH_DEFINE                          \
    pthread_t                       tid;            \
    uint64_t                        version_key;    \
    int8_t                          stoped;         \
    int8_t                          iot;            \
    int8_t                          started;        \
    int8_t                          errcode;        \
    int16_t                         hcode;          \
    int16_t                         idx;            \
    struct ev_loop*                 loop;           \
    ev_tstamp                       lastrun;        \
    ev_async                        thread_watcher; \
    easy_atomic_t                   thread_lock;    \
    easy_list_t                     task_list;      \
    easy_list_t                     pwait_list;     \
    easy_task_process_pt*           process;        \
    void*                           args;           \
    easy_uthread_control_t*         euc;            \
    easy_io_t*                      eio;            \
    easy_thread_pool_t*             etp;            \
    easy_baseth_on_start_pt*        on_start;       \
    easy_aio_t*                     aio;


struct easy_timeout_queue_t {
    easy_list_t head;
    ev_timer timer;
    int timeout;
    int cnt;
};

// 处理IO的线程
struct easy_io_thread_t {
    EASY_BASETH_DEFINE

    // listen watcher
    ev_timer                listen_watcher;

    // client list
    easy_list_t             client_list;
    easy_hash_t             *client_hash;
    easy_array_t            *client_array;
#ifdef HAVE_LIBSSL
    easy_array_t            *clissl_array;
#endif

    // connected list
    easy_list_t             connected_list;
    easy_atomic32_t         server_conn_count;
    easy_atomic32_t         doing_request_count;
    uint64_t                done_request_count;
    ev_tstamp               last_release_idle;

    //sample timer.
    uint64_t                send_count;
    easy_timeout_queue_t    timeout_queue[2];

};

// easy_coroutine_thread_t
struct easy_coroutine_thread_t {
    EASY_BASETH_DEFINE
};

// easy_comutex_t
struct easy_comutex_t {
    easy_atomic_t           wlock;
    easy_list_t             wlist;
    long                    lock;
    long                    owner;
};

// 保存client
struct easy_client_t {
    easy_addr_t             addr;
    easy_connection_t       *c;
    easy_io_handler_pt      *handler;
    easy_hash_link_t        client_hashnode;
    easy_list_t             client_listnode;
    int                     ref;
    int                     timeout;
#ifdef HAVE_LIBSSL
    easy_client_ssl_t       *ssl;
#endif
};

#ifdef HAVE_LIBSSL
struct easy_client_ssl_t {
    SSL_SESSION             *ssl_session;
    char                    *server_name;
};
#endif

// 对应一个SOCKET连接
struct easy_connection_t {
    EASY_TASK_NODE_HEADER(conn_list_node)
#ifdef EASY_DEBUG_MAGIC
    uint64_t                magic;
#endif
    uint32_t                status : 4;
    uint32_t                event_status : 4;
    uint32_t                type : 1;
    uint32_t                async_conn : 1;
    uint32_t                conn_has_error : 1;
    uint32_t                tcp_cork_flag : 1;
    uint32_t                wait_close : 1;
    uint32_t                need_redispatch : 1;
    uint32_t                read_eof : 1;
    uint32_t                auto_reconn : 1;
    uint32_t                life_idle : 1;
    uint32_t                is_tcp : 1;
    uint32_t                adaptive_rbuf : 1;

    // loop
    struct ev_loop          *loop;
    easy_pool_t             *pool;
    easy_io_thread_t        *ioth;

    // file description
    uint32_t                default_msglen;
    uint32_t                first_msglen;
    uint32_t                reconn_time : 24;
    uint32_t                reconn_fail : 8;
    int                     idle_time;
    int                     fd, seq;
    easy_addr_t             addr;

    ev_io                   read_watcher;
    ev_io                   write_watcher;
    ev_timer                timeout_watcher;
    easy_list_t             message_list;
    easy_list_t             pwait_node;

    easy_list_t             output;
    easy_io_handler_pt      *handler;
    easy_decode_pt          *decode;
    easy_encode_pt          *encode;
    easy_read_pt            *read;
    easy_write_pt           *write;
    union {
        struct {                              // server
            easy_list_t     server_requests;
            easy_list_t     *curr_requests;
        };
        struct {                              // client
            easy_client_t   *client;
            easy_hash_t     *send_queue;
        };
    };
    void                    *user_data;

    //////////////////////////////////////////////////
    uint16_t                qos_status;
    uint16_t                qos_gid;
    uint32_t                doing_request_count;
    uint32_t                pending_request_count;
    uint32_t                queue_size;

    ev_tstamp               start_time, last_time;
    ev_tstamp               wait_client_time, wcs;

#ifdef SUMMARY_ENABLE
    easy_summary_node_t     *con_summary;  //add for summary
#else
    uint32_t                done_request_count;
    uint32_t                output_bytes;
#endif
#ifdef HAVE_LIBSSL
    easy_ssl_connection_t   *sc;
#endif
    void                    *evdata;
};

#define EASY_REQUEST_HEADER                    \
    uint8_t                 istask : 1;        \
    uint8_t                 istimer : 1;       \
    uint8_t                 iscoro : 2;        \
    uint8_t                 status : 1;        \
    uint8_t                 waiting : 1;       \
    uint8_t                 block : 1;         \
    uint8_t                 alone : 1;         \
    int8_t                  retcode;           \
    int8_t                  packet_type;       \
    int                     reserved;          \
    uint64_t                hashkey;           \
    void                    *user_data;        \
    ev_timer                timeout_watcher;

// ipacket放进来的包, opacket及出去的包
struct easy_request_t {
    EASY_TASK_NODE_HEADER(request_list_node)
    EASY_REQUEST_HEADER

#ifdef EASY_DEBUG_DOING
    uint64_t                uuid;
#endif
#ifdef EASY_DEBUG_MAGIC
    uint64_t                magic;
#endif

    easy_message_session_t  *ms;
    easy_list_t             all_node;
    ev_tstamp               start_time;
    void                    *ipacket;
    void                    *opacket;
    void                    *args;
    easy_client_wait_t      *client_wait;
};

struct easy_task_t {
    EASY_TASK_NODE_HEADER(task_list_node)
    EASY_REQUEST_HEADER
};

#define EASY_MESSAGE_SESSION_HEADER(NAME, CODE) \
    EASY_TASK_NODE_HEADER(NAME)                 \
    int8_t                  async;              \
    int8_t                  status;             \
    int8_t                  error;              \
    int                     CODE;               \
    easy_connection_t       *c;                 \
    easy_pool_t             *pool;              \
     
struct easy_message_session_t {
    EASY_MESSAGE_SESSION_HEADER(task_list_node, align);
#ifdef EASY_DEBUG_MAGIC
    uint64_t                magic;
#endif
};

// 用于接收, 一个或多个easy_request_t
struct easy_message_t {
    EASY_MESSAGE_SESSION_HEADER(message_list_node, recycle_cnt);
#ifdef EASY_DEBUG_MAGIC
    uint64_t                magic;
#endif
    easy_buf_t              *input;
    //easy_list_t             message_list_node;
    easy_list_t             request_list;
    easy_list_t             all_list;
    int                     request_list_count;
    int                     next_read_len;

    void                    *user_data;
};

#ifdef SUMMARY_ENABLE
//用于统计流量rt信息
struct easy_summary_t {
    int                     max_fd;
    ev_tstamp               time;
    easy_atomic_t           lock;
    easy_pool_t             *pool;
    easy_summary_node_t     *bucket[EASY_SUMMARY_CNT];
};

struct easy_summary_node_t {
    int                     fd;
    uint32_t                doing_request_count;
    uint64_t                done_request_count;
    uint64_t                in_byte, out_byte;
    ev_tstamp               rt_total;
};
#endif

// 用于发送, 只带一个easy_request_t
struct easy_session_t {
    EASY_MESSAGE_SESSION_HEADER(session_list_node, timeout);
#ifdef EASY_DEBUG_MAGIC
    uint64_t                magic;
#endif
    ev_tstamp               now;
    ev_timer                timeout_watcher;

    easy_hash_list_t        send_queue_hash;
    easy_list_t             send_queue_list;
    easy_io_process_pt      *process;
    easy_io_cleanup_pt      *cleanup;
    easy_addr_t             addr;
    easy_list_t             *nextb;
    easy_message_t          *async_msg;

    uint64_t                packet_id;
    void                    *thread_ptr;
    easy_request_t          r;
    int32_t                 queuesize;
    int32_t                 r_timeout;
    easy_list_t             timeout_queue_node;
    ev_tstamp               send_time;

    char                    data[0];
};

// 监听列表
struct easy_listen_t {
    int                     fd;
    int8_t                  cur, old;
    uint8_t                 hidden_sum : 1;
    uint8_t                 reuseport : 1;
    uint8_t                 in_list : 1;
    easy_io_handler_pt      *handler;
    void                    *user_data;

    easy_addr_t             addr;
    easy_atomic_t           listen_lock;
    easy_io_thread_t        *curr_ioth;
    easy_io_thread_t        *old_ioth;
    easy_atomic_t           bind_port_cnt;

    easy_listen_t           *next;
    ev_io                   read_watcher[0];
};

// 用于统计处理速度
struct easy_io_stat_t {
    int64_t                 last_cnt;
    ev_tstamp               last_time;
    double                  last_speed;
    double                  total_speed;
    easy_io_stat_process_pt *process;
    easy_io_t               *eio;
};

// easy_io对象
struct easy_io_t {
    easy_pool_t             *pool;
    easy_list_t             eio_list_node;
    easy_atomic_t           lock;

    easy_listen_t           *listen;
    easy_listen_t           *listenadd;
    int                     io_thread_count;
    easy_thread_pool_t      *io_thread_pool;
    easy_thread_pool_t      *thread_pool;
    void                    *user_data;
    easy_list_t             thread_pool_list;

    // flags
    uint32_t                stoped : 2;
    uint32_t                started : 1;
    uint32_t                tcp_cork : 1;
    uint32_t                tcp_nodelay : 1;
    uint32_t                tcp_defer_accept : 1;
    uint32_t                listen_all : 1;
    uint32_t                affinity_enable : 1;
    uint32_t                no_redispatch : 2;     // 0 -> redispatch, 1 -> no dispatch, 2 -> first dispatch
    uint32_t                do_signal : 1;
    uint32_t                block_thread_signal : 1;
    uint32_t                support_ipv6 : 1;
    uint32_t                checkdrc : 1;
    uint32_t                no_reuseport : 1;
    uint32_t                use_accept4 : 1;
    uint32_t                no_delayack : 1;

    int32_t                 send_qlen;
    int32_t                 force_destroy_second; // second
    sigset_t                block_thread_sigset;
    int                     listen_backlog;
    int                     max_client_cnt;
    int                     queue_size;
    uint32_t                recv_vlen;

    ev_tstamp               start_time;
#ifdef SUMMARY_ENABLE
    easy_summary_t          *eio_summary;
#endif
    easy_io_t               *defio;
#ifdef HAVE_LIBSSL
    easy_ssl_t              *ssl;
#endif
};

// base thread
struct easy_baseth_t {
    EASY_BASETH_DEFINE
};

struct easy_thread_pool_t {
    easy_io_t              *eio;
    easy_list_t             once_start_list;
    easy_list_t             once_end_list;
    int                     thread_count;
    int                     member_size;
    int                     stoped;
    easy_atomic32_t         last_number;
    easy_list_t             list_node;
    easy_thread_pool_t      *next;
    char                    *last;
    pthread_t               monitor_tid;
    char                    data[0];
};

struct easy_cond_t {
    int                     fd[2];
    int                     epfd;
    int16_t                 len;
    int16_t                 pending;
};

struct easy_client_wait_t {
    int                     done_count;
    int                     status;
    pthread_mutex_t         mutex;
    pthread_cond_t          cond;
    easy_list_t             session_list;
    easy_list_t             next_list;
};

struct easy_file_task_t {
    int                     fd;
    int                     bufsize;
    char                    *buffer;
    int64_t                 offset;
    int64_t                 count;
    easy_buf_t              *b;
    void                    *args;
};

#ifdef HAVE_LIBSSL
struct easy_ssl_ctx_t {
    easy_pool_t             *pool;
    SSL_CTX                 *ctx;
    easy_list_t             list_node;
    int                     type;
    struct {
        char                    *file;
        int                     line;
        int                     prefer_server_ciphers;
        uint32_t                verify;
        uint32_t                verify_depth;
        int                     session_timeout;
        int                     session_cache;
        uint64_t                protocols;
        char                    *certificate;
        char                    *certificate_key;
        char                    *dhparam;
        char                    *client_certificate;
        char                    *crl;
        char                    *ciphers;
        char                    *server_name;
        char                    *pass_phrase_dialog;
        int                     session_reuse;
    } conf;
};

struct easy_ssl_connection_t {
    SSL                     *connection;
    easy_ssl_schandler_pt   *handler;

    int                     last;
    uint32_t                handshaked : 1;
    uint32_t                renegotiation : 1;
    uint32_t                session_reuse : 1;
};

struct easy_ssl_t {
    easy_list_t             server_list;
    easy_pool_t             *pool;
    easy_hash_t             *server_map;
    easy_hash_t             *client_map;

    easy_ssl_ctx_t          *server_ctx;
    easy_ssl_ctx_t          *client_ctx;
};
#endif

struct easy_thread_once_t {
    easy_list_t             node;
    easy_thread_once_pt    *once;
    void                   *args;
};

struct easy_aio_t {
    easy_pool_t            *pool;
    easy_array_t           *arr;
    int                     efd;
    int                     pending;
    int                     maxsize;
    int                     cursize;
    easy_list_t             list;
    ev_io                   watcher;
    easy_aio_ctx_t          ctx;
};

EASY_CPP_END

#endif

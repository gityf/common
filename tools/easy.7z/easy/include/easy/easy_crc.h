#ifndef EASY_CRC_H_
#define EASY_CRC_H_

/**
 * CRC函数
 */
#include <easy/easy_define.h>

EASY_CPP_START

extern uint32_t easy_crc32c(uint32_t crc, const uint8_t *data, uint64_t length);

EASY_CPP_END

#endif

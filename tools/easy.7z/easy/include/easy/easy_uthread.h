#ifndef EASY_UTHREAD_H
#define EASY_UTHREAD_H

#include <easy/easy_pool.h>
#include <easy/easy_list.h>

/**
 * 创建一用户态线程
 */

EASY_CPP_START

#define EASY_UTHREAD_READY     1
#define EASY_STACKBUF_SIZE     512

typedef void (easy_uthread_start_pt)(void *args, void *args2);
typedef struct easy_uthread_t easy_uthread_t;
typedef struct easy_uthread_control_t easy_uthread_control_t;

#if defined(__x86_64__)
typedef struct easy_ucontext_t {
    long rdi;
    long rsi;
    long rdx;
    long rcx;
    long r8;
    long r9;
    long rax;
    long rbx;
    long rbp;
    long r10;
    long r11;
    long r12;
    long r13;
    long r14;
    long r15;
    long rsp;
    long rip;
} easy_ucontext_t;
#else

#endif

struct easy_uthread_t {
    // EASY_TASK_NODE_HEADER START
    easy_list_t                task_list_node;
    void                       *task_process;
    void                       *task_args;
    int8_t                     task_type;
    int8_t                     exiting;
    int8_t                     protect;
    int8_t                     ready;
    uint32_t                   size;
    // EASY_TASK_NODE_HEADER END

    uint32_t                   tid;
    uint32_t                   coid;
    void                       *task_args2;
    void                       *threadptr;
    easy_ucontext_t            context;
    easy_list_t                thread_list_node;
    unsigned char              *buffer;
};

struct easy_uthread_control_t {
    uint32_t                   tid;
    uint32_t                   coid;
    int                        stoped;
    int                        thread_count;

    easy_list_t                runqueue;
    easy_list_t                thread_list;
    easy_uthread_t             *nbuf_list;
    int                        bufcnt;
    int                        align;

    easy_ucontext_t            context;
    easy_uthread_t             *running;
    void                       *threadptr;
};

// 函数
void easy_uthread_init(easy_uthread_control_t *control);
void easy_uthread_destroy();
easy_uthread_t *easy_uthread_current();
void easy_uthread_ready(easy_uthread_t *t);
void easy_uthread_switch();
void easy_uthread_print(int sig);
void easy_uthread_loop_yield(easy_uthread_control_t *euc);
int easy_uthread_exec(easy_uthread_control_t *euc, easy_uthread_start_pt *fn, void *args, void *args2);
uint64_t easy_uthread_id();

extern int easy_getcontext(easy_ucontext_t *ucp);
extern int easy_swapcontext(easy_ucontext_t *oucp, easy_ucontext_t *ucp);
extern void easy_gocontext(easy_uthread_t *t, long *sp, easy_ucontext_t *ucp);
extern void easy_context_start(easy_uthread_t *t);

extern __thread easy_uthread_control_t *easy_uthread_var;

EASY_CPP_END

#endif

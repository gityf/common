#ifndef EASY_FILE_H_
#define EASY_FILE_H_

#include <easy/easy_define.h>
#include <easy/easy_io_struct.h>

/**
 * 对文件操作
 */

EASY_CPP_START

#define EASY_MAX_FILE_BUFFER 65536

EASY_CPP_END

#endif


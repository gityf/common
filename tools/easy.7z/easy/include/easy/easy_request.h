#ifndef EASY_REQUEST_H_
#define EASY_REQUEST_H_

#include <easy/easy_define.h>
#include <easy/easy_io_struct.h>
#include <easy/easy_baseth_pool.h>

/**
 * 一个request对象
 */

EASY_CPP_START

void easy_request_server_done(easy_request_t *r);
void easy_request_client_done(easy_request_t *r);
void easy_request_set_cleanup(easy_request_t *r, easy_list_t *output);
extern int easy_connection_taskresp(easy_baseth_t *th, easy_task_t *r);

#define easy_request_wakeup_encode(r, packet, CODE)                                    \
    {                                                                                  \
        easy_request_t          *nr;                                                   \
        easy_io_thread_t        *ioth = r->ms->c->ioth;                                \
        nr = (easy_request_t *)easy_pool_alloc(r->ms->pool, sizeof(easy_request_t));   \
        memcpy(nr, r, sizeof(easy_request_t));                                         \
        nr->retcode = EASY_ENCODE;                                                     \
        easy_spin_lock(&ioth->thread_lock);                                            \
        if ((CODE)) {                                                                  \
            r->opacket = packet;                                                       \
            r->task_process = easy_connection_taskresp;                                \
            easy_list_add_tail(&r->request_list_node, &ioth->task_list);               \
        } else {                                                                       \
            nr->opacket = packet;                                                      \
            nr->task_process = easy_connection_taskresp;                               \
            easy_list_add_tail(&nr->request_list_node, &ioth->task_list);              \
        }                                                                              \
        easy_spin_unlock(&ioth->thread_lock);                                          \
        if ((easy_baseth_t*)ioth == easy_baseth_self) {                                \
            ioth->thread_watcher.sent = 2;                                             \
        } else {                                                                       \
            ev_async_send(ioth->loop, &ioth->thread_watcher);                          \
        }                                                                              \
    }

EASY_CPP_END

#endif


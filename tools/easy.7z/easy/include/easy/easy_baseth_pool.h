#ifndef EASY_BASETH_POOL_H
#define EASY_BASETH_POOL_H

#include <easy/easy_define.h>

/**
 * base pthread线程池
 */

EASY_CPP_START

#include <easy/easy_io_struct.h>

#define easy_thread_pool_for_each(th, tp, offset)                           \
    for((th) = (typeof(*(th))*)&(tp)->data[offset];                         \
            (char*)(th) < (tp)->last;                                       \
            th = (typeof(*th)*)(((char*)th) + (tp)->member_size))

#define easy_thread_pool_runloop(th)                                        \
    easy_uthread_control_t control __attribute__ ((aligned (64)));          \
    easy_uthread_init(&control);                                            \
    control.threadptr = th;                                                 \
    (th)->euc = &control;                                                   \
    easy_baseth_call_once((easy_baseth_t*)th,&((th)->etp->once_start_list));\
    ev_run(th->loop, 0);                                                    \
    easy_baseth_call_once((easy_baseth_t*)th, &((th)->etp->once_end_list)); \
    easy_uthread_destroy();

#define easy_baseth_async_p(ioth, r, p)                                     \
    (r)->task_process = p;                                                  \
    easy_baseth_async_lite((easy_baseth_t*)(ioth), (easy_task_t*)(r))

// 第n个
static inline void *easy_thread_pool_index(easy_thread_pool_t *tp, int n)
{
    if (n < 0 || n >= tp->thread_count)
        return NULL;

    return &tp->data[n * tp->member_size];
}

static inline void *easy_thread_pool_hash(easy_thread_pool_t *tp, uint64_t hv)
{
    hv %= tp->thread_count;
    return &tp->data[hv * tp->member_size];
}

static inline void *easy_thread_pool_rr(easy_thread_pool_t *tp, int start)
{
    int                     n, t;

    if ((t = tp->thread_count - start) > 0) {
        n = easy_atomic32_add_return(&tp->last_number, 1);
        n %= t;
        n += start;
    } else {
        n = 0;
    }

    return &tp->data[n * tp->member_size];
}

// baseth
void easy_baseth_on_wakeup(void *args);
void easy_baseth_init(void *args, easy_thread_pool_t *tp,
                      easy_baseth_on_start_pt *start, easy_baseth_on_wakeup_pt *wakeup);
easy_thread_pool_t *easy_baseth_pool_create(easy_io_t *eio, int thread_count, int member_size);
void easy_baseth_pool_start(easy_thread_pool_t *tp);
void easy_baseth_pool_stop(easy_thread_pool_t *tp);
void easy_baseth_pool_wait(easy_thread_pool_t *tp);
void easy_baseth_pool_destroy(easy_thread_pool_t *tp);
void easy_baseth_pool_monitor(easy_thread_pool_t *tp);
void easy_baseth_call_once(easy_baseth_t *th, easy_list_t *list);
void easy_baseth_on_process(struct ev_loop *loop, ev_async *w, int revents);
void easy_baseth_async_lite(easy_baseth_t *ioth, easy_task_t *r);
int easy_baseth_task_process(easy_baseth_t *th, easy_task_t *r);

int easy_thread_pool_push(easy_thread_pool_t *tp, easy_request_t *r, uint64_t hv);
int easy_thread_pool_addin(easy_thread_pool_t *tp, easy_task_t *r, uint64_t hv);
int easy_thread_pool_later(easy_task_t *r);

EASY_CPP_END

#endif

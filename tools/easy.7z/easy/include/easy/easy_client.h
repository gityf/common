#ifndef EASY_CLIENT_H_
#define EASY_CLIENT_H_

#include <easy/easy_define.h>
#include <easy/easy_io_struct.h>

/**
 * 主动连接管理
 */

EASY_CPP_START

easy_client_t *easy_client_list_find(easy_hash_t *table, easy_addr_t *addr);
int easy_client_list_add(easy_hash_t *table, easy_addr_t *addr, easy_hash_link_t *list);

EASY_CPP_END

#endif

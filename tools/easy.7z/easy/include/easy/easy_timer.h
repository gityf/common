#ifndef EASY_TIMER_H
#define EASY_TIMER_H
#include <easy/easy_define.h>
#include <easy/easy_io_struct.h>

inline int easy_timeout_queue_addin(easy_timeout_queue_t *q, easy_session_t *s);
inline int easy_timeout_queue_update(easy_timeout_queue_t *q, easy_session_t *s);

#endif

#ifndef EASY_AIO_H_
#define EASY_AIO_H_

#include <easy/easy_define.h>
#include <easy/easy_io_struct.h>

/**
 * 对文件异步读写操作
 */

EASY_CPP_START

/* these are internal to the kernel/libc. */
typedef struct easy_iocb_t {
    uint64_t   aio_data;
    uint32_t   aio_key, aio_reserved1;
    uint16_t   aio_lio_opcode;
    int16_t    aio_reqprio;
    uint32_t   aio_fildes;
    uint64_t   aio_buf;
    uint64_t   aio_nbytes;
    int64_t    aio_offset;
    uint64_t   aio_reserved2;
    uint32_t   aio_flags;
    uint32_t   aio_resfd;
} easy_iocb_t;

typedef struct easy_aio_event_t {
    uint64_t  data;  /* the data field from the iocb */
    uint64_t  obj;   /* what iocb this event came from */
    int64_t   res;   /* result code for this event */
    int64_t   res2;  /* secondary result */
} easy_aio_event_t;

typedef void (easy_aio_callback_pt)(easy_aio_event_t *event, void *args);
typedef struct easy_aio_task_t {
    easy_list_t          node;
    easy_aio_callback_pt *cb;
    void                 *args;
    easy_iocb_t           iocb;
} easy_aio_task_t;

typedef enum easy_io_iocb_cmd {
    EIO_CMD_PREAD = 0,
    EIO_CMD_PWRITE = 1,
    EIO_CMD_FSYNC = 2,
    EIO_CMD_FDSYNC = 3,
    EIO_CMD_POLL = 5,
    EIO_CMD_NOOP = 6,
    EIO_CMD_PREADV = 7,
    EIO_CMD_PWRITEV = 8,
} easy_io_iocb_cmd_t;

extern easy_aio_task_t *easy_aio_newtask();
extern int easy_aio_dotask(easy_aio_task_t **tsk, int cnt);
#define easy_aio_inittask(tsk, cmd, fd, buf, count, offset, pcb, pargs) \
    tsk->cb = pcb;                                                      \
    tsk->args = pargs;                                                  \
    tsk->iocb.aio_lio_opcode = cmd;                                     \
    tsk->iocb.aio_fildes = fd;                                          \
    tsk->iocb.aio_buf = (long) buf;                                     \
    tsk->iocb.aio_nbytes = count;                                       \
    tsk->iocb.aio_offset = offset;

EASY_CPP_END

#endif
